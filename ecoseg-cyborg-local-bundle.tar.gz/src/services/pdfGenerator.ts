import { jsPDF } from 'jspdf';
import { SlideData, LECTURE_FULL_SLIDES } from './pptxGenerator';

/**
 * Generates a high-fidelity 16:9 PDF presentation using jsPDF,
 * styled with the EcoSeg architectural brand identity.
 */
export async function generatePdf(slidesToExport?: SlideData[]): Promise<void> {
  const slides = slidesToExport && slidesToExport.length > 0 ? slidesToExport : LECTURE_FULL_SLIDES;

  // 16:9 Landscape dimensions in mm (297mm width x 167.06mm height)
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: [297, 167.06]
  });

  const width = doc.internal.pageSize.getWidth();
  const height = doc.internal.pageSize.getHeight();

  // Colors
  const BG_COLOR = [8, 13, 20]; // #080D14 Obsidian Navy
  const SURFACE_COLOR = [17, 24, 39]; // #111827 Dark Surface
  const GOLD_COLOR = [197, 168, 128]; // #C5A880 Imperial Brass
  const TEXT_WHITE = [248, 249, 250]; // #F8F9FA Alabaster Pearl
  const TEXT_MUTED = [148, 163, 184]; // #94A3B8 Muted Slate
  const BORDER_COLOR = [38, 50, 56]; // #263238 Subtle line

  slides.forEach((slide, index) => {
    if (index > 0) {
      doc.addPage([297, 167.06], 'landscape');
    }

    // 1. Dark Background
    doc.setFillColor(BG_COLOR[0], BG_COLOR[1], BG_COLOR[2]);
    doc.rect(0, 0, width, height, 'F');

    // 2. Top Golden Line Accent
    doc.setFillColor(GOLD_COLOR[0], GOLD_COLOR[1], GOLD_COLOR[2]);
    doc.rect(0, 0, width, 1.8, 'F');

    // Top Header: Brand Wordmark
    doc.setTextColor(GOLD_COLOR[0], GOLD_COLOR[1], GOLD_COLOR[2]);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text('ECOSEG', 18, 12);

    doc.setTextColor(TEXT_MUTED[0], TEXT_MUTED[1], TEXT_MUTED[2]);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.text('PROTEÇÃO DA FAMÍLIA MILITAR · CTA / RJ', 18, 17);

    // Top Right: Act & Category Kicker
    doc.setTextColor(GOLD_COLOR[0], GOLD_COLOR[1], GOLD_COLOR[2]);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    const kickerText = `${slide.act.toUpperCase()}   |   ${slide.kicker}`;
    doc.text(kickerText, width - 18, 13, { align: 'right' });

    // Divider Line
    doc.setDrawColor(BORDER_COLOR[0], BORDER_COLOR[1], BORDER_COLOR[2]);
    doc.setLineWidth(0.3);
    doc.line(18, 22, width - 18, 22);

    // 3. Main Slide Title
    doc.setTextColor(TEXT_WHITE[0], TEXT_WHITE[1], TEXT_WHITE[2]);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(20);
    const titleLines = doc.splitTextToSize(slide.title, width - 36);
    doc.text(titleLines, 18, 34);

    // Subtitle
    const titleHeight = (titleLines.length - 1) * 8;
    const subY = 41 + titleHeight;
    doc.setTextColor(TEXT_MUTED[0], TEXT_MUTED[1], TEXT_MUTED[2]);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(11);
    const subLines = doc.splitTextToSize(slide.subtitle, width - 36);
    doc.text(subLines, 18, subY);

    // 4. Content Area (Bullet Points & Metric Box)
    const contentY = subY + (subLines.length * 6) + 4;
    const pointsWidth = slide.metric ? 165 : 255;

    let currentY = contentY;
    slide.points.forEach((point) => {
      // Golden bullet
      doc.setFillColor(GOLD_COLOR[0], GOLD_COLOR[1], GOLD_COLOR[2]);
      doc.circle(20, currentY - 1, 1, 'F');

      // Point text
      doc.setTextColor(TEXT_WHITE[0], TEXT_WHITE[1], TEXT_WHITE[2]);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10.5);
      const pointLines = doc.splitTextToSize(point, pointsWidth);
      doc.text(pointLines, 24, currentY);

      currentY += (pointLines.length * 5.5) + 3;
    });

    // 5. Metric Card (if available)
    if (slide.metric) {
      const metricX = width - 85;
      const metricY = contentY;
      const metricW = 67;
      const metricH = 46;

      // Card Background
      doc.setFillColor(SURFACE_COLOR[0], SURFACE_COLOR[1], SURFACE_COLOR[2]);
      doc.setDrawColor(GOLD_COLOR[0], GOLD_COLOR[1], GOLD_COLOR[2]);
      doc.setLineWidth(0.5);
      doc.roundedRect(metricX, metricY, metricW, metricH, 3, 3, 'FD');

      // Metric Value
      doc.setTextColor(GOLD_COLOR[0], GOLD_COLOR[1], GOLD_COLOR[2]);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(26);
      doc.text(slide.metric.value, metricX + (metricW / 2), metricY + 18, { align: 'center' });

      // Metric Label
      doc.setTextColor(TEXT_WHITE[0], TEXT_WHITE[1], TEXT_WHITE[2]);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      const labelLines = doc.splitTextToSize(slide.metric.label, metricW - 10);
      doc.text(labelLines, metricX + (metricW / 2), metricY + 28, { align: 'center' });
    }

    // 6. Citation / Quote (if available)
    if (slide.citation) {
      const quoteY = Math.max(currentY + 2, height - 32);
      doc.setDrawColor(GOLD_COLOR[0], GOLD_COLOR[1], GOLD_COLOR[2]);
      doc.setLineWidth(0.8);
      doc.line(18, quoteY - 3, 18, quoteY + 6);

      doc.setTextColor(GOLD_COLOR[0], GOLD_COLOR[1], GOLD_COLOR[2]);
      doc.setFont('times', 'italic');
      doc.setFontSize(10);
      const quoteLines = doc.splitTextToSize(slide.citation, 240);
      doc.text(quoteLines, 22, quoteY + 1);
    }

    // 7. Footer Bar
    const footerY = height - 12;
    doc.setDrawColor(30, 41, 59);
    doc.setLineWidth(0.3);
    doc.line(18, footerY - 3, width - 18, footerY - 3);

    doc.setTextColor(100, 116, 139);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(
      'ECOSEG Consultoria  ·  Evento no Clube dos Taifeiros da Aeronáutica (CTA)  ·  21/10/2026',
      18,
      footerY + 2
    );

    doc.setTextColor(GOLD_COLOR[0], GOLD_COLOR[1], GOLD_COLOR[2]);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.text(
      `Slide ${index + 1} de ${slides.length}`,
      width - 18,
      footerY + 2,
      { align: 'right' }
    );
  });

  // Save the PDF file
  doc.save('EcoSeg_Palestra_CTA_Lei13954.pdf');
}
