import * as pdfjsLib from 'pdfjs-dist';
import { SlideData } from './pptxGenerator';

// Use CDN worker to avoid Vite bundling worker binary issues
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version || '4.10.38'}/pdf.worker.min.mjs`;

export async function parsePdfFile(file: File): Promise<SlideData[]> {
  const arrayBuffer = await file.arrayBuffer();
  const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(arrayBuffer) });
  const pdf = await loadingTask.promise;
  const slides: SlideData[] = [];

  for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
    const page = await pdf.getPage(pageNum);
    const textContent = await page.getTextContent();
    
    // Group text items by their vertical position (y coordinate) or join text
    const textItems = textContent.items as Array<any>;
    const extractedLines: string[] = [];
    let currentLine = '';

    for (const item of textItems) {
      const str = item.str || '';
      if (str.trim().length > 0) {
        currentLine += (currentLine ? ' ' : '') + str.trim();
        // If has eol or major punctuation
        if (item.hasEOL || str.endsWith('.') || str.endsWith(':') || currentLine.length > 90) {
          extractedLines.push(currentLine.trim());
          currentLine = '';
        }
      }
    }
    if (currentLine.trim()) {
      extractedLines.push(currentLine.trim());
    }

    const cleanLines = extractedLines.filter(l => l.length > 1);
    const title = cleanLines[0] || `Página / Slide ${pageNum}`;
    const subtitle = cleanLines[1] || '';
    const points = cleanLines.slice(2).filter(p => p.length > 0);

    slides.push({
      act: `Slide 0${pageNum} · PDF Importado`,
      title: title.slice(0, 90),
      subtitle: subtitle.slice(0, 140) || 'Conteúdo estruturado da apresentação em PDF.',
      kicker: 'ENSAIO DE PALESTRA',
      points: points.length > 0 ? points.slice(0, 5) : [subtitle || 'Tópico extraído do documento original.'],
      speakerNotes: `Notas de Apresentação (Página ${pageNum} do PDF):\n- Pontos principais extraídos do documento.\n- Contextualizar para a família militar.\n\nTexto original: ${cleanLines.slice(0, 3).join(' ')}`,
      timeAllocationMinutes: Math.max(2, Math.min(6, Math.round((points.length + 1) * 1.2)))
    });
  }

  return slides;
}
