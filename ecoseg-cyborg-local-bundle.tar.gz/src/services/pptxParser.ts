import JSZip from 'jszip';
import { SlideData } from './pptxGenerator';

/**
 * Parses a .pptx file in the browser using JSZip, extracting slides and notes.
 */
export async function parsePptxFile(file: File): Promise<SlideData[]> {
  const zip = new JSZip();
  const loadedZip = await zip.loadAsync(file);

  // Find all slide XML files: ppt/slides/slide1.xml, slide2.xml, etc.
  const slideFileNames: string[] = [];
  loadedZip.forEach((relativePath) => {
    if (relativePath.match(/^ppt\/slides\/slide\d+\.xml$/)) {
      slideFileNames.push(relativePath);
    }
  });

  // Sort slides numerically: slide1, slide2, slide10, etc.
  slideFileNames.sort((a, b) => {
    const numA = parseInt(a.match(/slide(\d+)\.xml/)?.[1] || '0', 10);
    const numB = parseInt(b.match(/slide(\d+)\.xml/)?.[1] || '0', 10);
    return numA - numB;
  });

  const parsedSlides: SlideData[] = [];

  for (let i = 0; i < slideFileNames.length; i++) {
    const slidePath = slideFileNames[i];
    const slideIndex = i + 1;
    const slideXml = await loadedZip.file(slidePath)?.async('text');

    if (!slideXml) continue;

    // Parse text from XML
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(slideXml, 'text/xml');

    // Extract all paragraphs (<a:p>)
    const paragraphNodes = xmlDoc.getElementsByTagName('a:p');
    const paragraphs: string[] = [];

    for (let p = 0; p < paragraphNodes.length; p++) {
      const pNode = paragraphNodes[p];
      const textNodes = pNode.getElementsByTagName('a:t');
      let pText = '';
      for (let t = 0; t < textNodes.length; t++) {
        pText += textNodes[t].textContent || '';
      }
      pText = pText.trim();
      if (pText.length > 0) {
        paragraphs.push(pText);
      }
    }

    // Try to load corresponding notes slide if present: ppt/notesSlides/notesSlide1.xml
    let notesText = '';
    const notesPath = `ppt/notesSlides/notesSlide${slideIndex}.xml`;
    const notesXml = await loadedZip.file(notesPath)?.async('text');
    if (notesXml) {
      const notesDoc = parser.parseFromString(notesXml, 'text/xml');
      const noteTexts = notesDoc.getElementsByTagName('a:t');
      const noteParagraphs: string[] = [];
      for (let nt = 0; nt < noteTexts.length; nt++) {
        const txt = noteTexts[nt].textContent?.trim();
        if (txt && !txt.match(/^(Slide \d+|\d+)$/)) {
          noteParagraphs.push(txt);
        }
      }
      notesText = noteParagraphs.join('\n');
    }

    // Determine Title, Subtitle, and Points
    let title = paragraphs[0] || `Slide ${slideIndex}`;
    let subtitle = '';
    let points: string[] = [];

    if (paragraphs.length === 1) {
      title = paragraphs[0];
      points = ['Conteúdo institucional adaptado para o padrão visual EcoSeg.'];
    } else if (paragraphs.length === 2) {
      title = paragraphs[0];
      subtitle = paragraphs[1];
      points = [paragraphs[1]];
    } else {
      title = paragraphs[0];
      subtitle = paragraphs[1];
      points = paragraphs.slice(2);
    }

    parsedSlides.push({
      act: `Ato 0${slideIndex} · Apresentação Importada`,
      title: title,
      subtitle: subtitle || 'Estruturado para comunicação consultiva de alta autoridade.',
      kicker: 'ENSAIO PERSONALIZADO',
      points: points.length > 0 ? points : ['Tópico de apresentação estruturado.'],
      speakerNotes: notesText || `Roteiro do Slide ${slideIndex}:\n- Apresentar com clareza os pontos centrais.\n- Contextualizar o cenário para o público presente.`,
      timeAllocationMinutes: Math.max(2, Math.round(points.length * 1.2))
    });
  }

  return parsedSlides;
}

/**
 * Parses raw text input (e.g. copied from PowerPoint or markdown)
 */
export function parseRawTextToSlides(rawText: string): SlideData[] {
  const slideBlocks = rawText
    .split(/\n(?:---|\={3,}|(?:Slide|SLIDE)\s*\d+[:\.-]?)/i)
    .map(b => b.trim())
    .filter(b => b.length > 0);

  if (slideBlocks.length === 0) {
    return [];
  }

  return slideBlocks.map((block, idx) => {
    const lines = block.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    const title = lines[0]?.replace(/^[#*\-•\s]+/, '') || `Slide ${idx + 1}`;
    const subtitle = lines[1]?.replace(/^[#*\-•\s]+/, '') || '';
    const points = lines.slice(2).map(l => l.replace(/^[-*•\d\.]+\s*/, '')).filter(l => l.length > 0);

    return {
      act: `Ato 0${idx + 1} · Ensaio`,
      title,
      subtitle,
      kicker: 'CONTEÚDO DA PALESTRA',
      points: points.length > 0 ? points : [subtitle || 'Tópico principal a ser abordado.'],
      speakerNotes: `Notas de Ensaio para o Slide ${idx + 1}:\n- Foco em clareza e ritmo.\n- Destacar a segurança da família militar.`,
      timeAllocationMinutes: 3
    };
  });
}
