export type LogoVariant = 'primary' | 'stacked' | 'symbol-only' | 'seal';
export type BackgroundSurface = 'obsidian' | 'pearl' | 'slate' | 'bronze' | 'pure-black';
export type SymbolFinish = 'brass' | 'platinum' | 'carbon' | 'emerald';
export type ActiveTab = 'overview' | 'symbol' | 'colors' | 'typography' | 'applications' | 'governance' | 'messaging' | 'docs' | 'cyborg';

export interface ColorToken {
  id: string;
  name: string;
  category: 'primary' | 'accent' | 'neutral' | 'surface';
  hex: string;
  rgb: string;
  cmyk: string;
  pantone?: string;
  role: string;
  ratio: string;
  description: string;
  lightText: boolean;
}

export interface TypoScaleItem {
  level: string;
  element: string;
  sizePx: number;
  lineHeight: string;
  weight: string;
  tracking: string;
  usage: string;
  sample: string;
}

export interface SlideItem {
  id: number;
  act: string;
  title: string;
  subtitle: string;
  kicker: string;
  points: string[];
  citation?: string;
  metric?: {
    value: string;
    label: string;
  };
}
