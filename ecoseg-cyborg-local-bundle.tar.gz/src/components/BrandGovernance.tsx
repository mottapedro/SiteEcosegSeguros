import React from 'react';
import { ShieldX, CheckCircle, AlertTriangle, Lock, Eye, Ban } from 'lucide-react';
import { EcoSegLogo } from './EcoSegLogo';

export const BrandGovernance: React.FC = () => {
  return (
    <div className="space-y-10">
      {/* Header Statement */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-neutral-800/60">
        <div>
          <span className="text-xs font-semibold tracking-widest text-amber-400/90 uppercase">
            Governança da Marca & Brandbook
          </span>
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-white mt-1">
            Princípios Não-Negociáveis & Eliminação de Contradições
          </h2>
          <p className="text-sm text-neutral-400 mt-1.5 max-w-2xl leading-relaxed">
            Diretrizes formais para encerrar a divergência entre a documentação arquitetural da EcoSeg
            e o código publicado, consolidando o novo posicionamento consultivo para famílias militares.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-rose-500/10 border border-rose-500/30 rounded-lg text-rose-300 text-xs font-semibold">
          <Ban className="w-3.5 h-3.5" />
          <span>Veto a Símbolos de Seguradora Tradicional</span>
        </div>
      </div>

      {/* The Crucial Contrast: ShieldCheck Ban vs The Geometric Monolith */}
      <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-6 space-y-6">
        <div>
          <h3 className="text-base font-semibold text-white">
            A Resolução da Contradição Central: Por que o Escudo foi Abolido
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            A ADR 0005 veta explicitamente escudos, guarda-chuvas e mãos de amparo. Compare o erro anterior com a solução aprovada:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Previous Incorrect Cliché */}
          <div className="p-6 rounded-xl border border-rose-900/40 bg-rose-950/10 space-y-4">
            <div className="flex items-center justify-between text-xs font-mono text-rose-400">
              <span className="flex items-center gap-1.5 font-semibold">
                <ShieldX className="w-4 h-4 text-rose-500" />
                PADRÃO BANIDO (ShieldCheck)
              </span>
              <span className="text-rose-500/80">Erro de Posicionamento</span>
            </div>

            <div className="h-32 rounded-lg bg-neutral-950 flex flex-col items-center justify-center border border-rose-900/30 text-center p-4">
              <div className="w-12 h-12 rounded-full bg-rose-500/10 flex items-center justify-center text-rose-400 mb-2">
                <ShieldX className="w-7 h-7" />
              </div>
              <span className="text-xs text-neutral-400 font-mono">Ícone ShieldCheck genérico</span>
            </div>

            <div className="text-xs text-neutral-300 space-y-1.5">
              <p className="font-semibold text-rose-300">Por que viola a marca EcoSeg:</p>
              <ul className="list-disc list-inside space-y-1 text-neutral-400">
                <li>Comunica venda de seguro de varejo (carro, celular, residencial comum).</li>
                <li>Transmite paranoia ou ameaça externa, em vez de planejamento consciente.</li>
                <li>Desrespeita o militar, que já possui armas e escudo institucionais.</li>
              </ul>
            </div>
          </div>

          {/* Current Approved Vector Solution */}
          <div className="p-6 rounded-xl border border-emerald-900/40 bg-emerald-950/10 space-y-4">
            <div className="flex items-center justify-between text-xs font-mono text-emerald-400">
              <span className="flex items-center gap-1.5 font-semibold">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                NOVO SÍMBOLO ECOSEG APROVADO
              </span>
              <span className="text-emerald-400/80">Arquitetura & Horizonte</span>
            </div>

            <div className="h-32 rounded-lg bg-[#080D14] flex flex-col items-center justify-center border border-neutral-800 p-4">
              <EcoSegLogo variant="primary" size={44} finish="brass" />
            </div>

            <div className="text-xs text-neutral-300 space-y-1.5">
              <p className="font-semibold text-emerald-300">Por que expressa a verdade da EcoSeg:</p>
              <ul className="list-disc list-inside space-y-1 text-neutral-300">
                <li>Comunica estabilidade jurídica e planejamento familiar de longo prazo.</li>
                <li>Simboliza a viga mestra de sustentação e a visão clara das leis.</li>
                <li>Alinhado à nobreza dos clubes militares e advocacias de alta cúpula.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Brand Matrix: What EcoSeg IS vs What EcoSeg IS NOT */}
      <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl overflow-hidden">
        <div className="p-5 border-b border-neutral-800">
          <h3 className="text-base font-semibold text-white">Matriz de Identidade & Tom de Voz</h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            Critérios para redação de textos, postagens, slides e materiais da palestra.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-neutral-800">
          {/* What it IS */}
          <div className="p-6 space-y-4 bg-emerald-950/5">
            <h4 className="text-xs font-mono font-semibold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
              <CheckCircle className="w-4 h-4" /> A EcoSeg É:
            </h4>
            <div className="space-y-3 text-xs text-neutral-300">
              <div className="p-3 bg-neutral-950/70 rounded-lg border border-emerald-900/30">
                <span className="font-semibold text-white block">Consultoria Jurídico-Patrimonial</span>
                <span className="text-neutral-400 mt-0.5 block">
                  Focada em mapeamento de riscos específicos da carreira militar e regras de transição.
                </span>
              </div>
              <div className="p-3 bg-neutral-950/70 rounded-lg border border-emerald-900/30">
                <span className="font-semibold text-white block">Diagnóstico ANTES de Solução</span>
                <span className="text-neutral-400 mt-0.5 block">
                  Apresenta a dor, o contexto legal e a vulnerabilidade antes de qualquer contratação.
                </span>
              </div>
              <div className="p-3 bg-neutral-950/70 rounded-lg border border-emerald-900/30">
                <span className="font-semibold text-white block">Dignidade & Sobriedade Institucional</span>
                <span className="text-neutral-400 mt-0.5 block">
                  Comunicação respeitosa com vocabulário de oficiais, veteranos e pensionistas.
                </span>
              </div>
            </div>
          </div>

          {/* What it is NOT */}
          <div className="p-6 space-y-4 bg-rose-950/5">
            <h4 className="text-xs font-mono font-semibold uppercase tracking-wider text-rose-400 flex items-center gap-2">
              <ShieldX className="w-4 h-4" /> A EcoSeg NÃO É:
            </h4>
            <div className="space-y-3 text-xs text-neutral-300">
              <div className="p-3 bg-neutral-950/70 rounded-lg border border-rose-900/30">
                <span className="font-semibold text-white block">Corretora de Balcão / Varejo</span>
                <span className="text-neutral-400 mt-0.5 block">
                  Não empurra apólices padronizadas nem trata o militar como número de comissão.
                </span>
              </div>
              <div className="p-3 bg-neutral-950/70 rounded-lg border border-rose-900/30">
                <span className="font-semibold text-white block">Terrorismo Comercial</span>
                <span className="text-neutral-400 mt-0.5 block">
                  Não utiliza medo vulgar ("sua família vai passar fome"), e sim lucidez matemática.
                </span>
              </div>
              <div className="p-3 bg-neutral-950/70 rounded-lg border border-rose-900/30">
                <span className="font-semibold text-white block">Página Genérica de Seguros</span>
                <span className="text-neutral-400 mt-0.5 block">
                  Sem botões fluorescentes, sem contadores regressivos falsos e sem ícones infantis.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Safety Margins and Reproducibility */}
      <div className="p-6 bg-neutral-900/60 border border-neutral-800 rounded-xl space-y-4">
        <h3 className="text-base font-semibold text-white">
          Área de Respiro & Reduções Mínimas
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-neutral-300">
          <div className="p-4 bg-neutral-950 rounded-lg border border-neutral-800 space-y-1.5">
            <span className="text-amber-400 font-mono text-[11px] block">ÁREA DE ISOLAMENTO (X)</span>
            <p className="text-neutral-400">
              A distância mínima ao redor do símbolo equivale à altura da barra horizontal de apoio (1.5X). Nenhum texto ou elemento gráfico pode invadir esse espaço.
            </p>
          </div>

          <div className="p-4 bg-neutral-950 rounded-lg border border-neutral-800 space-y-1.5">
            <span className="text-amber-400 font-mono text-[11px] block">REDUÇÃO MÍNIMA DIGITAL</span>
            <p className="text-neutral-400">
              <strong>Favicon:</strong> 16x16px (monograma simplificado).<br />
              <strong>Mobile Header:</strong> Altura mínima de 28px para a marca completa.
            </p>
          </div>

          <div className="p-4 bg-neutral-950 rounded-lg border border-neutral-800 space-y-1.5">
            <span className="text-amber-400 font-mono text-[11px] block">REDUÇÃO MÍNIMA IMPRESSA</span>
            <p className="text-neutral-400">
              <strong>Cartões & Papelaria:</strong> 12mm de largura mínima para garantir a nitidez do filete dourado em hot-stamping.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
