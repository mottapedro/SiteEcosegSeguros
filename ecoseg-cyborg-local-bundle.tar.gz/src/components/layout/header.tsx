import React, { useState } from "react";
import { EcoSegLogo } from "../brand/EcoSegLogo";
import { Menu, X, ArrowRight, Phone } from "lucide-react";

interface NavLink {
  href: string;
  label: string;
}

const NAV_LINKS: NavLink[] = [
  { href: "/palestra/protecao-familia-militar", label: "Palestra Militar" },
  { href: "/#metodologia", label: "Metodologia Consultiva" },
  { href: "/#diagnostico", label: "Diagnóstico Consultivo" },
  { href: "/contato", label: "Contato" },
];

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-neutral-800/80 bg-[#080D14]/95 backdrop-blur-md">
      {/* Container Principal: Eixo X e Y com respiro arquitetural nobre */}
      <div className="mx-auto flex h-18 sm:h-20 w-full max-w-[1600px] items-center justify-between px-4 sm:px-6 lg:px-8 xl:px-12 2xl:px-16">
        
        {/* Zona 1 (Esquerda): Marca Oficial EcoSeg — Alinhamento Ótico Seguro */}
        <a
          href="/"
          className="group flex items-center shrink-0 transition-opacity hover:opacity-95"
          aria-label="EcoSeg — Planejamento e Proteção Patrimonial"
        >
          <EcoSegLogo
            size={38}
            finish="brass"
            tagline="PLANEJAMENTO & PROTEÇÃO PATRIMONIAL"
          />
        </a>

        {/* Zona 2 (Centro): Menu de Navegação em Linha Única sem quebra de texto */}
        <nav
          className="hidden h-full items-center justify-center gap-5 xl:gap-8 2xl:gap-10 lg:flex flex-1 px-6 xl:px-12"
          aria-label="Navegação principal"
        >
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="relative py-2 text-[11px] xl:text-xs font-semibold tracking-wider text-neutral-300 uppercase transition-colors hover:text-white whitespace-nowrap after:absolute after:bottom-0 after:left-0 after:h-[2px] after:w-0 after:bg-[#C5A880] after:transition-all hover:after:w-full"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zona 3 (Direita): Ações Primárias & Secundárias */}
        <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
          <a
            href="/palestra/protecao-familia-militar/apresentacao"
            className="hidden xl:inline-flex items-center justify-center whitespace-nowrap rounded-xl border border-neutral-800 bg-neutral-900/90 hover:bg-neutral-800 px-3.5 xl:px-4 py-2 sm:py-2.5 text-xs font-semibold text-neutral-200 hover:text-white transition-all shadow-sm"
          >
            Modo Apresentação
          </a>

          <a
            href="/contato"
            className="inline-flex cursor-pointer items-center justify-center whitespace-nowrap rounded-xl bg-[#C5A880] hover:bg-[#b5966c] px-4 xl:px-5 py-2 sm:py-2.5 text-xs font-bold text-[#080D14] shadow-md shadow-[#C5A880]/20 transition-all active:scale-95"
          >
            Agendar Diagnóstico
          </a>

          {/* Botão Hambúrguer Mobile/Tablet (lg:hidden) */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="inline-flex lg:hidden items-center justify-center p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-900 border border-neutral-800 transition-colors cursor-pointer"
            aria-label={mobileMenuOpen ? "Fechar menu" : "Abrir menu"}
            aria-expanded={mobileMenuOpen}
          >
            {mobileMenuOpen ? <X className="w-5 h-5 text-neutral-200" /> : <Menu className="w-5 h-5 text-neutral-200" />}
          </button>
        </div>
      </div>

      {/* Menu Dropdown Mobile / Tablet com Espaçamento X/Y e Toque Confortável */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-neutral-800 bg-[#080D14]/98 backdrop-blur-2xl px-4 py-5 animate-in fade-in-0 duration-200">
          <div className="flex flex-col space-y-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-between py-3 px-3 rounded-lg text-xs font-semibold uppercase tracking-wider text-neutral-300 hover:text-white hover:bg-neutral-900/60 transition-colors border-b border-neutral-850 last:border-b-0"
              >
                <span>{link.label}</span>
                <ArrowRight className="w-3.5 h-3.5 text-neutral-500" />
              </a>
            ))}
          </div>

          <div className="pt-4 mt-2 border-t border-neutral-800 flex flex-col gap-2.5">
            <a
              href="/palestra/protecao-familia-militar/apresentacao"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center justify-center py-2.5 px-4 rounded-xl text-xs font-semibold text-neutral-200 bg-neutral-900 border border-neutral-800 hover:bg-neutral-800 transition-colors text-center"
            >
              Modo Apresentação (Palestra CTA)
            </a>
            <a
              href="https://wa.me/5521994693673"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-2 text-xs text-neutral-400 hover:text-emerald-400 transition-colors font-mono"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              <span>WhatsApp: (21) 99469-3673</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
