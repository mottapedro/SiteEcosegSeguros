import React, { useState } from 'react';
import { EcoSegLogo } from './EcoSegLogo';
import { LogoVariant, BackgroundSurface, SymbolFinish } from '../types/brand';
import { Sliders, Grid, Download, Copy, Check, Eye, Maximize2 } from 'lucide-react';

export const LogoLab: React.FC = () => {
  const [variant, setVariant] = useState<LogoVariant>('primary');
  const [surface, setSurface] = useState<BackgroundSurface>('obsidian');
  const [finish, setFinish] = useState<SymbolFinish>('brass');
  const [showGrid, setShowGrid] = useState<boolean>(false);
  const [strokeWidth, setStrokeWidth] = useState<number>(2.2);
  const [size, setSize] = useState<number>(72);
  const [tagline, setTagline] = useState<string>('PLANEJAMENTO & PROTEÇÃO PATRIMONIAL');
  const [copied, setCopied] = useState<boolean>(false);

  const surfaceBgClass: Record<BackgroundSurface, string> = {
    obsidian: 'bg-[#080D14] text-neutral-100 border-neutral-800/80',
    pearl: 'bg-[#F8F9FA] text-neutral-900 border-neutral-200',
    slate: 'bg-[#0F172A] text-neutral-100 border-neutral-800',
    bronze: 'bg-[#181613] text-amber-50 border-amber-950/60',
    'pure-black': 'bg-black text-white border-neutral-900'
  };

  const handleCopySvg = () => {
    const svgElement = document.querySelector('#preview-stage svg');
    if (svgElement) {
      navigator.clipboard.writeText(svgElement.outerHTML);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadSvg = () => {
    const svgElement = document.querySelector('#preview-stage svg');
    if (svgElement) {
      const svgData = svgElement.outerHTML;
      const blob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const downloadLink = document.createElement('a');
      downloadLink.href = url;
      downloadLink.download = `ecoseg-logo-${variant}-${finish}.svg`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header Statement */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-neutral-800/60">
        <div>
          <span className="text-xs font-semibold tracking-widest text-amber-400/90 uppercase">
            Laboratório Vetorial & Identidade Visual
          </span>
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-white mt-1">
            O Símbolo Arquitetônico EcoSeg
          </h2>
          <p className="text-sm text-neutral-400 mt-1.5 max-w-2xl leading-relaxed">
            Substituição mandatória do antigo escudo de seguradora genérica por um símbolo geométrico puro:
            unindo a <strong>viga de estabilidade jurídica</strong> à <strong>abertura panorâmica de horizonte</strong>.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopySvg}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-neutral-200 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded-lg transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Código SVG Copiado!' : 'Copiar Código SVG'}</span>
          </button>
          <button
            onClick={handleDownloadSvg}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-amber-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors font-semibold cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Baixar Vetor .SVG</span>
          </button>
        </div>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Visual Stage (Left / Center) */}
        <div className="lg:col-span-8 space-y-4">
          <div
            id="preview-stage"
            className={`relative min-h-[420px] rounded-xl border p-8 flex flex-col items-center justify-center transition-all duration-300 overflow-hidden shadow-2xl ${surfaceBgClass[surface]}`}
          >
            {/* Subtle background radial aura */}
            <div className="absolute inset-0 pointer-events-none opacity-40 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-500/5 via-transparent to-transparent" />

            {/* Quick Badges / Status */}
            <div className="absolute top-4 left-4 flex items-center gap-2 text-[11px] font-mono opacity-70">
              <span className="text-neutral-400">Variante:</span>
              <span className="font-semibold uppercase text-amber-400">{variant}</span>
              <span className="text-neutral-600">|</span>
              <span className="text-neutral-400">Escala:</span>
              <span className="text-neutral-300">{size}px</span>
            </div>

            <div className="absolute top-4 right-4 flex items-center gap-1.5">
              <button
                onClick={() => setShowGrid(!showGrid)}
                className={`flex items-center gap-1.5 px-2.5 py-1 text-[11px] rounded border transition-colors cursor-pointer ${
                  showGrid
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    : 'bg-neutral-900/60 text-neutral-400 border-neutral-800 hover:text-white'
                }`}
              >
                <Grid className="w-3 h-3" />
                <span>Grid Áureo {showGrid ? 'Ativo' : 'Oculto'}</span>
              </button>
            </div>

            {/* Rendered Logo Component */}
            <div className="py-12 z-10 select-none">
              <EcoSegLogo
                variant={variant}
                surface={surface}
                finish={finish}
                showGrid={showGrid}
                strokeWidth={strokeWidth}
                size={size}
                tagline={tagline}
              />
            </div>

            {/* Stage bottom info bar */}
            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-[11px] text-neutral-400 border-t border-neutral-800/40 pt-3">
              <div className="flex items-center gap-3">
                <span className="font-mono">Área Segura: 1.5X</span>
                <span>·</span>
                <span className="font-mono">Proporção Áurea: 1:1.618</span>
              </div>
              <span className="font-mono text-neutral-500">Vetores Puros (0 Raster)</span>
            </div>
          </div>

          {/* Anatomy Explanatory Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 pt-2">
            <div className="p-3.5 bg-neutral-900/60 border border-neutral-800/60 rounded-lg">
              <span className="text-[10px] font-mono text-amber-400/90 block">01. VIGA ESTRUTURAL</span>
              <h4 className="text-xs font-semibold text-neutral-200 mt-1">Apoio Patrimonial</h4>
              <p className="text-[11px] text-neutral-400 mt-1 leading-relaxed">
                Base reta horizontal que transmite segurança jurídica inabalável e solidez das instituições militares.
              </p>
            </div>

            <div className="p-3.5 bg-neutral-900/60 border border-neutral-800/60 rounded-lg">
              <span className="text-[10px] font-mono text-amber-400/90 block">02. ARCO DE HORIZONTE</span>
              <h4 className="text-xs font-semibold text-neutral-200 mt-1">Compreensão Ampla</h4>
              <p className="text-[11px] text-neutral-400 mt-1 leading-relaxed">
                Abertura panorâmica sobre as mudanças nas pensões e leis, antecipando lacunas antes da contratação.
              </p>
            </div>

            <div className="p-3.5 bg-neutral-900/60 border border-neutral-800/60 rounded-lg">
              <span className="text-[10px] font-mono text-amber-400/90 block">03. PIVÔ EM DIAMANTE</span>
              <h4 className="text-xs font-semibold text-neutral-200 mt-1">Decisão Consultiva</h4>
              <p className="text-[11px] text-neutral-400 mt-1 leading-relaxed">
                Núcleo geométrico central que simboliza o diagnóstico estratégico individualizado para cada família.
              </p>
            </div>

            <div className="p-3.5 bg-neutral-900/60 border border-neutral-800/60 rounded-lg">
              <span className="text-[10px] font-mono text-amber-400/90 block">04. FLUXO 'E' & 'S'</span>
              <h4 className="text-xs font-semibold text-neutral-200 mt-1">Monograma EcoSeg</h4>
              <p className="text-[11px] text-neutral-400 mt-1 leading-relaxed">
                Integração harmoniosa das letras iniciais sem recorrer a formas decorativas arbitrárias ou infantis.
              </p>
            </div>
          </div>
        </div>

        {/* Controls Sidebar (Right) */}
        <div className="lg:col-span-4 p-5 bg-neutral-900/70 border border-neutral-800 rounded-xl space-y-6">
          <div className="flex items-center gap-2 pb-3 border-b border-neutral-800 text-neutral-200 font-semibold text-sm">
            <Sliders className="w-4 h-4 text-amber-400" />
            <span>Configurações do Símbolo</span>
          </div>

          {/* 1. Variante do Logotipo */}
          <div className="space-y-2">
            <label className="text-xs font-medium text-neutral-300 block">
              Composição da Marca
            </label>
            <div className="grid grid-cols-2 gap-1.5 p-1 bg-neutral-950 rounded-lg border border-neutral-800">
              <button
                onClick={() => setVariant('primary')}
                className={`px-3 py-1.5 text-xs font-medium rounded transition-colors text-left cursor-pointer ${
                  variant === 'primary' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Horizontal (Padrão)
              </button>
              <button
                onClick={() => setVariant('stacked')}
                className={`px-3 py-1.5 text-xs font-medium rounded transition-colors text-left cursor-pointer ${
                  variant === 'stacked' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Vertical (Apresentações)
              </button>
              <button
                onClick={() => setVariant('symbol-only')}
                className={`px-3 py-1.5 text-xs font-medium rounded transition-colors text-left cursor-pointer ${
                  variant === 'symbol-only' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Monograma Isolado
              </button>
              <button
                onClick={() => setVariant('seal')}
                className={`px-3 py-1.5 text-xs font-medium rounded transition-colors text-left cursor-pointer ${
                  variant === 'seal' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Chancela / Selo Oficial
              </button>
            </div>
          </div>

          {/* 2. Acabamento do Símbolo */}
          <div className="space-y-2">
            <label className="text-xs font-medium text-neutral-300 block">
              Acabamento & Metalização
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setFinish('brass')}
                className={`flex items-center gap-2 p-2 rounded-lg border text-xs text-left transition-colors cursor-pointer ${
                  finish === 'brass'
                    ? 'border-amber-500/60 bg-amber-500/10 text-amber-300'
                    : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
                }`}
              >
                <div className="w-3.5 h-3.5 rounded-full bg-[#C5A880] border border-amber-300/40" />
                <span>Dourado Latão</span>
              </button>

              <button
                onClick={() => setFinish('platinum')}
                className={`flex items-center gap-2 p-2 rounded-lg border text-xs text-left transition-colors cursor-pointer ${
                  finish === 'platinum'
                    ? 'border-neutral-400/60 bg-neutral-800 text-white'
                    : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
                }`}
              >
                <div className="w-3.5 h-3.5 rounded-full bg-white border border-neutral-300" />
                <span>Platina Nobre</span>
              </button>

              <button
                onClick={() => setFinish('carbon')}
                className={`flex items-center gap-2 p-2 rounded-lg border text-xs text-left transition-colors cursor-pointer ${
                  finish === 'carbon'
                    ? 'border-neutral-700 bg-neutral-800 text-neutral-200'
                    : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
                }`}
              >
                <div className="w-3.5 h-3.5 rounded-full bg-[#0F172A] border border-neutral-700" />
                <span>Preto Carbono</span>
              </button>

              <button
                onClick={() => setFinish('emerald')}
                className={`flex items-center gap-2 p-2 rounded-lg border text-xs text-left transition-colors cursor-pointer ${
                  finish === 'emerald'
                    ? 'border-emerald-500/60 bg-emerald-500/10 text-emerald-300'
                    : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
                }`}
              >
                <div className="w-3.5 h-3.5 rounded-full bg-[#10B981] border border-emerald-400/40" />
                <span>Verde Eco Puro</span>
              </button>
            </div>
          </div>

          {/* 3. Superfície de Fundo */}
          <div className="space-y-2">
            <label className="text-xs font-medium text-neutral-300 block">
              Superfície de Aplicação
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setSurface('obsidian')}
                className={`p-2 rounded-lg border text-xs text-left transition-colors cursor-pointer ${
                  surface === 'obsidian' ? 'border-amber-500/50 bg-neutral-800 text-white' : 'border-neutral-800 bg-neutral-950 text-neutral-400'
                }`}
              >
                Obsidian Navy (Escuro)
              </button>
              <button
                onClick={() => setSurface('pearl')}
                className={`p-2 rounded-lg border text-xs text-left transition-colors cursor-pointer ${
                  surface === 'pearl' ? 'border-neutral-300 bg-neutral-200 text-neutral-900 font-semibold' : 'border-neutral-800 bg-neutral-950 text-neutral-400'
                }`}
              >
                Papel Alabastro (Claro)
              </button>
              <button
                onClick={() => setSurface('slate')}
                className={`p-2 rounded-lg border text-xs text-left transition-colors cursor-pointer ${
                  surface === 'slate' ? 'border-sky-500/50 bg-neutral-800 text-white' : 'border-neutral-800 bg-neutral-950 text-neutral-400'
                }`}
              >
                Slate Corporativo
              </button>
              <button
                onClick={() => setSurface('bronze')}
                className={`p-2 rounded-lg border text-xs text-left transition-colors cursor-pointer ${
                  surface === 'bronze' ? 'border-amber-700/60 bg-[#1e1b17] text-amber-200' : 'border-neutral-800 bg-neutral-950 text-neutral-400'
                }`}
              >
                Bronze Solene
              </button>
            </div>
          </div>

          {/* 4. Fine-Tuning Sliders */}
          <div className="space-y-4 pt-2 border-t border-neutral-800">
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-neutral-300">
                <span>Espessura da Linha (Stroke)</span>
                <span className="font-mono text-amber-400">{strokeWidth}px</span>
              </div>
              <input
                type="range"
                min="1.4"
                max="3.5"
                step="0.2"
                value={strokeWidth}
                onChange={(e) => setStrokeWidth(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-neutral-300">
                <span>Dimensão do Símbolo</span>
                <span className="font-mono text-amber-400">{size}px</span>
              </div>
              <input
                type="range"
                min="44"
                max="140"
                step="4"
                value={size}
                onChange={(e) => setSize(parseInt(e.target.value))}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>

            {/* Custom Tagline Input */}
            <div className="space-y-1.5 pt-1">
              <label className="text-xs text-neutral-300 block">
                Assinatura / Descriptor
              </label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                className="w-full px-3 py-1.5 text-xs bg-neutral-950 border border-neutral-800 rounded-lg text-neutral-200 focus:outline-none focus:border-amber-400/80"
                placeholder="PLANEJAMENTO & PROTEÇÃO PATRIMONIAL"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
