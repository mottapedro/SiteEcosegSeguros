import React, { useState } from 'react';
import {
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Scale,
  FileText,
  Lock,
  Globe,
  Database,
  Users,
  Presentation,
  ArrowRight,
  Code2,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Cpu,
  BookOpen,
  Briefcase,
  Phone,
  Sparkles,
  Check,
  ShieldCheck
} from 'lucide-react';
import {
  NORMAS_JURIDICAS_GOVERNADAS,
  LACUNAS_PROTECAO_MILITAR,
  CATEGORIAS_SOLUCAO_PRIVADA,
  ROTEIRO_PALESTRA_CTA
} from '../domain/military-family/data';
import { PRODUTOS_SOLUCOES_ECOSEG } from '../domain/military-family/products';

interface DomainEcosystemPanelProps {
  onOpenDoc?: (docPath: string) => void;
}

export const DomainEcosystemPanel: React.FC<DomainEcosystemPanelProps> = ({ onOpenDoc }) => {
  const [activeSubTab, setActiveSubTab] = useState<'produtos' | 'matriz' | 'fronteira' | 'militar' | 'palestra' | 'lgpd'>('produtos');
  const [selectedPartnerFilter, setSelectedPartnerFilter] = useState<string>('Todos');
  const [expandedProblem, setExpandedProblem] = useState<number | null>(null);

  const problemas = [
    {
      id: 1,
      titulo: 'Navegação promete páginas que não existem',
      status: 'Mapeado para V1',
      impacto: 'Alto - Quebra de experiência',
      detalhes: 'Rotas como /empresa, /servicos, /blog anunciadas no menu sem rotas correspondentes em src/app.',
      resolucao: 'Poda de rotas estáticas na V1 e priorização de: Home, Palestra CTA, Diagnóstico e Contato.'
    },
    {
      id: 2,
      titulo: 'Dados fictícios publicados no site',
      status: 'Corrigido no Domínio',
      impacto: 'Crítico - Quebra de credibilidade',
      detalhes: 'Telefone (+55 11 0000-0000) e WhatsApp apontando para São Paulo enquanto a operação é no RJ (CTA).',
      resolucao: 'Substituição no siteConfig e nos componentes pelo telefone e WhatsApp oficial (21) 99469-3673, e-mail contato@ecoseg.com.br e praça Rio de Janeiro / CTA.'
    },
    {
      id: 3,
      titulo: 'Home apresenta produto antes de demonstrar a dor',
      status: 'Reestruturado',
      impacto: 'Alto - Filosofia de Marca',
      detalhes: 'Sequência genérica (Hero → Produtos → Diferenciais) viola a ordem: Contexto → Compreensão → Lacuna → Decisão → Proteção.',
      resolucao: 'Reordenamento da Home da palestra: Expectativa Militar → Mudança Jurídica → Lacuna → Diagnóstico → Solução.'
    },
    {
      id: 4,
      titulo: 'Contradição visual: ícone de escudo (ShieldCheck)',
      status: 'Resolvido (ADR-B-001)',
      impacto: 'Médio - Consistência de Marca',
      detalhes: 'ADR-B-001 veta escudos/cadeados. O logotipo representa compreensão e estrutura de horizonte.',
      resolucao: 'Aplicação da EcoSegLogo oficial com acabamento Latão Nobre no Header e Footer.'
    },
    {
      id: 5,
      titulo: 'Novo domínio militar inexistente na arquitetura',
      status: 'Implementado em src/domain',
      impacto: 'Crítico - Modelo de Negócio',
      detalhes: 'O sistema só conhecia seguros corporativos, sem modelos para Leis, Artigos, Militares e Lacunas.',
      resolucao: 'Criação dos tipos formais e banco de dados de domínio em src/domain/military-family/.'
    },
    {
      id: 6,
      titulo: 'Formulário ainda não adequado à LGPD',
      status: 'Contrato Neutro Criado',
      impacto: 'Crítico - Risco Regulatório',
      detalhes: 'Coleta de dados sem finalidade, base legal ou rastreabilidade de consentimento.',
      resolucao: 'Implementação de consentimento explícito fundamentado no Art. 7º V/IX da Lei 13.709/2018.'
    },
    {
      id: 7,
      titulo: 'Acoplamento arquitetural pontual',
      status: 'Desacoplado',
      impacto: 'Médio - Manutenibilidade',
      detalhes: 'services/email importava tipos diretamente de features/contact-form.',
      resolucao: 'Contrato neutro LeadDiagnosticoPublicoContract isolado na camada de domínio.'
    },
    {
      id: 8,
      titulo: 'Proteções operacionais provisórias',
      status: 'Fronteira Delimitada',
      impacto: 'Alto - Segurança & Escala',
      detalhes: 'Rate limit em memória no Vercel serverless e ausência de banco de dados persistente.',
      resolucao: 'Delimitação da fronteira: Site público leve na Vercel e motor confidencial na Cyborg Intelligence.'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Banner Principal de Intenção do Sistema */}
      <div className="rounded-2xl border border-amber-500/30 bg-gradient-to-r from-neutral-900 via-neutral-900 to-amber-950/20 p-6 sm:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold">
              <Cpu className="w-3.5 h-3.5 text-amber-400" />
              <span>Intenção Estratégica do Ecossistema ECOSEG</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-wide">
              Transição: Corretora Genérica → Plataforma Consultiva Governada
            </h2>
            <p className="text-sm text-neutral-300 max-w-3xl leading-relaxed">
              O ecossistema foi reorganizado para acomodar a tese consultiva validada com João no Clube dos Taifeiros (CTA-RJ):
              <strong> Compreensão do contexto militar</strong>, fundamentação na <strong>Lei nº 13.954/2019</strong> e separação estrita
              entre o site público e a plataforma privada SaaS da <strong>Cyborg Tecnologia</strong>.
            </p>
          </div>

          <div className="flex flex-wrap lg:flex-col gap-3 shrink-0">
            {onOpenDoc && (
              <button
                onClick={() => onOpenDoc('domain/ecoseg-domain-ecosystem-intent.md')}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-amber-500 text-neutral-950 font-semibold text-xs hover:bg-amber-400 transition-colors cursor-pointer shadow-md"
              >
                <BookOpen className="w-4 h-4" />
                <span>Ler Documento de Intenção</span>
              </button>
            )}
            {onOpenDoc && (
              <button
                onClick={() => onOpenDoc('adr/0005-ecoseg-public-site-cyborg-consulting-platform.md')}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-neutral-800 text-neutral-200 border border-neutral-700 font-semibold text-xs hover:bg-neutral-700 transition-colors cursor-pointer"
              >
                <FileText className="w-4 h-4 text-amber-400" />
                <span>ADR 0005 (Site vs SaaS)</span>
              </button>
            )}
            {onOpenDoc && (
              <button
                onClick={() => onOpenDoc('adr/0007-cyborg-intelligence-saas-core-architecture.md')}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-semibold text-xs hover:bg-cyan-500/30 transition-colors cursor-pointer"
              >
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span>ADR 0007 (Núcleo Cyborg)</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Subnavegação do Painel - Carousel Horizontal no Mobile */}
      <div className="flex items-center overflow-x-auto no-scrollbar gap-2 border-b border-neutral-800 pb-3 -mx-4 px-4 sm:mx-0 sm:px-0 sm:flex-wrap">
        {[
          { id: 'produtos', label: '1. Produtos & Soluções (Icatu / GBOEX / MAG)', shortLabel: '1. Produtos', icon: Briefcase },
          { id: 'matriz', label: '2. Matriz dos 8 Problemas', shortLabel: '2. 8 Problemas', icon: AlertTriangle },
          { id: 'fronteira', label: '3. Fronteira ECOSEG × Cyborg', shortLabel: '3. Fronteira', icon: Layers },
          { id: 'militar', label: '4. Domínio Militar & Leis', shortLabel: '4. Domínio Militar', icon: Scale },
          { id: 'palestra', label: '5. Roteiro da Palestra (CTA)', shortLabel: '5. Palestra CTA', icon: Presentation },
          { id: 'lgpd', label: '6. Governança LGPD', shortLabel: '6. LGPD', icon: Lock }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`inline-flex items-center gap-2 px-3 sm:px-3.5 py-2 rounded-lg text-xs font-medium transition-all cursor-pointer shrink-0 whitespace-nowrap active:scale-95 ${
                isActive
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm font-semibold'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-neutral-500'}`} />
              <span className="hidden sm:inline">{tab.label}</span>
              <span className="sm:hidden">{tab.shortLabel}</span>
            </button>
          );
        })}
      </div>

      {/* SubTab 0: Produtos & Soluções Privadas (Icatu / GBOEX / MAG) */}
      {activeSubTab === 'produtos' && (
        <div className="space-y-6">
          {/* Header e Filtros */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900/60 border border-neutral-800 p-4 rounded-xl">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-amber-400" />
                <span>Opções de Produtos para Suprir Ausências de Direitos (Lei 13.954)</span>
              </h3>
              <p className="text-xs text-neutral-400 mt-0.5">
                Soluções homologadas pelas seguradoras parceiras para a família militar e planejamento sucessório.
              </p>
            </div>

            <div className="flex items-center overflow-x-auto no-scrollbar gap-1.5 pb-1 sm:pb-0 sm:flex-wrap shrink-0">
              {['Todos', 'Icatu Seguros', 'GBOEX', 'MAG Seguros', 'Consultoria Previdenciária'].map(partner => (
                <button
                  key={partner}
                  onClick={() => setSelectedPartnerFilter(partner)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer shrink-0 whitespace-nowrap ${
                    selectedPartnerFilter === partner
                      ? 'bg-amber-400 text-neutral-950 font-semibold'
                      : 'bg-neutral-950 text-neutral-400 hover:text-white border border-neutral-800'
                  }`}
                >
                  {partner}
                </button>
              ))}
            </div>
          </div>

          {/* Grid de Cards de Produtos */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {PRODUTOS_SOLUCOES_ECOSEG.filter(
              prod => selectedPartnerFilter === 'Todos' || prod.seguradora === selectedPartnerFilter
            ).map(produto => {
              const partnerBadgeColors: Record<string, string> = {
                'Icatu Seguros': 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
                GBOEX: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
                'MAG Seguros': 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
                'Consultoria Previdenciária': 'bg-amber-500/10 text-amber-400 border-amber-500/30'
              };

              return (
                <div
                  key={produto.id}
                  className="rounded-2xl border border-neutral-800/90 bg-neutral-900/70 p-5 space-y-4 hover:border-amber-500/40 transition-all flex flex-col justify-between shadow-lg"
                >
                  <div className="space-y-3">
                    {/* Header do Card */}
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full border ${
                            partnerBadgeColors[produto.seguradora] || 'bg-neutral-800 text-neutral-300'
                          }`}
                        >
                          {produto.seguradora}
                        </span>
                        {['Icatu Seguros', 'MAG Seguros', 'GBOEX'].includes(produto.seguradora) && (
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                            API Conectada
                          </span>
                        )}
                      </div>
                      {produto.processoSusep && (
                        <span className="text-[10px] font-mono text-neutral-500 bg-neutral-950 px-2 py-0.5 rounded border border-neutral-800">
                          SUSEP {produto.processoSusep}
                        </span>
                      )}
                    </div>

                    <div>
                      <h4 className="text-base font-bold text-white tracking-wide">
                        {produto.nome}
                      </h4>
                      <p className="text-xs text-amber-300/90 font-medium mt-0.5 leading-snug">
                        {produto.subtitulo}
                      </p>
                    </div>

                    <p className="text-xs text-neutral-300 leading-relaxed">
                      {produto.descricao}
                    </p>

                    {/* Vantagem Sucessória / Jurídica em destaque */}
                    <div className="rounded-xl bg-neutral-950 p-3 border border-amber-500/20 text-xs space-y-1">
                      <div className="flex items-center gap-1.5 text-amber-400 font-semibold text-[11px] uppercase tracking-wider">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Vantagem Sucessória & Anti-Inventário</span>
                      </div>
                      <p className="text-neutral-300 text-xs leading-relaxed">
                        {produto.vantagemSucessoria}
                      </p>
                    </div>

                    {/* Lista de Destaques Técnicos */}
                    <div className="space-y-1.5 pt-1">
                      <span className="text-[10px] font-mono uppercase tracking-wider text-neutral-400 block">
                        Diferenciais do Plano:
                      </span>
                      <ul className="space-y-1 text-xs text-neutral-300">
                        {produto.destaques.slice(0, 4).map((d, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                            <span>{d}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Rodapé do Card com CTA WhatsApp */}
                  <div className="pt-3 border-t border-neutral-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="text-[11px] text-neutral-400">
                      <span>Consultoria EcoSeg · Rio de Janeiro / CTA</span>
                    </div>

                    <a
                      href={`https://wa.me/5521994693673?text=Ol%C3%A1%2C%20gostaria%20de%20informa%C3%A7%C3%B5es%20sobre%20o%20${encodeURIComponent(
                        produto.nome
                      )}%20para%20a%20fam%C3%ADlia%20militar.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 px-3.5 py-2 rounded-xl bg-neutral-950 hover:bg-neutral-800 text-amber-300 border border-amber-500/30 hover:border-amber-400 text-xs font-semibold transition-all shadow-sm group"
                    >
                      <Phone className="w-3.5 h-3.5 text-emerald-400 group-hover:scale-110 transition-transform" />
                      <span>Cotar pelo WhatsApp (21) 99469-3673</span>
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SubTab 1: Matriz dos 8 Problemas Prioritários */}
      {activeSubTab === 'matriz' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-neutral-400 px-1">
            <span>Diagnóstico Arquitetural Registrado</span>
            <span className="font-mono text-amber-400">8/8 problemas endereçados no domínio</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {problemas.map(p => {
              const isExpanded = expandedProblem === p.id;
              return (
                <div
                  key={p.id}
                  className="rounded-xl border border-neutral-800 bg-neutral-900/70 p-4 transition-all hover:border-neutral-700"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-500/20 text-[11px] font-bold text-amber-400 font-mono">
                        {p.id}
                      </span>
                      <div>
                        <h4 className="text-xs font-semibold text-white leading-tight">
                          {p.titulo}
                        </h4>
                        <div className="mt-1 flex items-center gap-2 text-[10px]">
                          <span className="text-neutral-400">{p.impacto}</span>
                          <span>·</span>
                          <span className="text-emerald-400 font-medium">{p.status}</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setExpandedProblem(isExpanded ? null : p.id)}
                      className="text-neutral-400 hover:text-white p-1 cursor-pointer"
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>

                  {isExpanded && (
                    <div className="mt-3 pt-3 border-t border-neutral-800/80 space-y-2 text-xs">
                      <div>
                        <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-500">Causa Raiz:</span>
                        <p className="text-neutral-300 mt-0.5">{p.detalhes}</p>
                      </div>
                      <div className="rounded bg-neutral-950/80 p-2 border border-neutral-800">
                        <span className="text-[10px] uppercase font-mono tracking-wider text-amber-400/90">Diretriz de Domínio:</span>
                        <p className="text-neutral-200 mt-0.5">{p.resolucao}</p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SubTab 2: Fronteira ECOSEG × Cyborg Intelligence */}
      {activeSubTab === 'fronteira' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Superfície Pública: ECOSEG */}
          <div className="rounded-xl border border-blue-500/30 bg-neutral-900/60 p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/30">
                <Globe className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">ECOSEG — Superfície Pública</h3>
                <p className="text-xs text-neutral-400">Repositório `SiteEcosegSeguros` (Next.js 16 / Vercel)</p>
              </div>
            </div>

            <ul className="space-y-2.5 text-xs text-neutral-300">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <span>Identidade e posicionamento institucional de autoridade</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <span>Página do evento / Palestra no Clube dos Taifeiros (CTA-RJ)</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <span>Modo Apresentação do Palestrante com notas de palco</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <span>Simulador de Lacunas de baixa sensibilidade para o público</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <span>Consentimento explícito e aviso de privacidade LGPD</span>
              </li>
            </ul>

            <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-400">
              <strong className="text-neutral-200">Princípio Arquitetural:</strong> Nunca armazena dados de saúde, prontuários ou regras comerciais reutilizáveis por terceiros.
            </div>
          </div>

          {/* Plataforma Privada: Cyborg Intelligence */}
          <div className="rounded-xl border border-amber-500/30 bg-neutral-900/60 p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/30">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Cyborg Intelligence — SaaS B2B Privado</h3>
                <p className="text-xs text-neutral-400">Repositório Privado (Propriedade Cyborg Tecnologia)</p>
              </div>
            </div>

            <ul className="space-y-2.5 text-xs text-neutral-300">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Motor determinístico de aderência e recomendação de apólices</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Base jurídica completa versionada com jurisprudência militar</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Prontuário consultivo familiar confidencial com auditoria</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Autenticação, RBAC e gestão de organizações e consultores</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>API comercial para futuras corretoras parceiras</span>
              </li>
            </ul>

            <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-400">
              <strong className="text-neutral-200">Propriedade Intelectual:</strong> A ECOSEG é cliente piloto e ambiente de validação; a propriedade do motor pertence à Cyborg Tecnologia.
            </div>

            {onOpenDoc && (
              <button
                onClick={() => onOpenDoc('adr/0007-cyborg-intelligence-saas-core-architecture.md')}
                className="w-full inline-flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-semibold transition-colors cursor-pointer"
              >
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span>Explorar Arquitetura do SaaS (ADR 0007)</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* SubTab 3: Domínio Militar & Leis Governadas */}
      {activeSubTab === 'militar' && (
        <div className="space-y-6">
          {/* Normas Jurídicas */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Scale className="w-4 h-4 text-amber-400" />
              <span>Normas Jurídicas Governadas no Código</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {NORMAS_JURIDICAS_GOVERNADAS.map(norma => (
                <div key={norma.id} className="rounded-xl border border-neutral-800 bg-neutral-900/70 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-semibold text-amber-400">{norma.codigo}</span>
                    <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 text-[10px] font-mono uppercase">
                      {norma.statusValidacao}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">{norma.lei} — {norma.artigo}</h4>
                    <p className="text-[11px] text-neutral-400 mt-0.5">{norma.vigencia}</p>
                  </div>
                  <div className="space-y-1.5 text-xs">
                    <div className="rounded bg-neutral-950 p-2 border border-neutral-800 text-neutral-300">
                      <strong className="text-neutral-400 text-[10px] block uppercase">Regra Anterior:</strong>
                      {norma.regraAnterior}
                    </div>
                    <div className="rounded bg-neutral-950 p-2 border border-amber-900/30 text-amber-200/90">
                      <strong className="text-amber-400 text-[10px] block uppercase">Regra Atual pós-13.954:</strong>
                      {norma.regraAtual}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Lacunas vs Soluções */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>Lacunas Mapeadas vs Soluções Privadas Complementares</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {LACUNAS_PROTECAO_MILITAR.map(lacuna => (
                <div key={lacuna.id} className="rounded-xl border border-neutral-800 bg-neutral-900/70 p-4 space-y-3 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between text-[10px] font-mono mb-2">
                      <span className="text-red-400 uppercase font-semibold">Severidade {lacuna.severidade}</span>
                      <span className="text-amber-400 font-bold">-{lacuna.percentualPerdaRenda}% Renda</span>
                    </div>
                    <h4 className="text-xs font-bold text-white">{lacuna.titulo}</h4>
                    <p className="text-xs text-neutral-400 mt-2 leading-relaxed">{lacuna.descricaoCurta}</p>
                  </div>
                  <div className="pt-3 border-t border-neutral-800">
                    <span className="text-[10px] font-mono text-neutral-500 uppercase block">Solução Recomendada:</span>
                    <span className="text-xs text-amber-300 font-medium">Seguro Resgatável / Fundo de Liquidez</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SubTab 4: Roteiro Narrativo da Palestra CTA */}
      {activeSubTab === 'palestra' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-neutral-400 px-1">
            <span>Roteiro de Palco do Palestrante João (Clube dos Taifeiros / CTA-RJ)</span>
            <span className="font-mono text-amber-400">6 Fases Narrativas</span>
          </div>

          <div className="space-y-3">
            {ROTEIRO_PALESTRA_CTA.map(bloco => (
              <div
                key={bloco.ordem}
                className="rounded-xl border border-neutral-800 bg-neutral-900/70 p-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-3">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-amber-500/20 text-xs font-bold text-amber-400 font-mono">
                    0{bloco.ordem}
                  </span>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400/80 bg-amber-500/10 px-2 py-0.5 rounded">
                        {bloco.fase}
                      </span>
                      <span className="text-xs text-neutral-400 font-mono">~{bloco.tempoSugeridoMinutos} min</span>
                    </div>
                    <h4 className="text-sm font-bold text-white">{bloco.tituloSlide}</h4>
                    <p className="text-xs text-neutral-300 italic">"{bloco.ganchoEmocional}"</p>
                  </div>
                </div>

                <div className="shrink-0 md:text-right space-y-1 pl-10 md:pl-0">
                  <span className="text-[10px] font-mono uppercase text-neutral-500 block">Ação do Público no Site:</span>
                  <span className="text-xs font-medium text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded inline-block">
                    {bloco.acaoPublicoNoSite}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SubTab 5: Governança LGPD */}
      {activeSubTab === 'lgpd' && (
        <div className="rounded-xl border border-neutral-800 bg-neutral-900/70 p-6 space-y-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Governança & Adequação à LGPD (Lei nº 13.709/2018)</h3>
              <p className="text-xs text-neutral-400">Resolução do Ponto 6: Coleta Minimizada e Consentimento Transparente</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="rounded-lg bg-neutral-950 p-4 border border-neutral-800 space-y-2">
              <h4 className="font-semibold text-white">Fundamento Legal Específico</h4>
              <p className="text-neutral-300 leading-relaxed">
                Coleta com base no <strong>Artigo 7º, Inciso V</strong> da LGPD (procedimentos preliminares relacionados a contrato a pedido do titular)
                e <strong>Artigo 7º, Inciso IX</strong> (legítimo interesse do controlador na prevenção de desamparo familiar militar).
              </p>
            </div>

            <div className="rounded-lg bg-neutral-950 p-4 border border-neutral-800 space-y-2">
              <h4 className="font-semibold text-white">Regra de Minimização de Dados</h4>
              <p className="text-neutral-300 leading-relaxed">
                Na superfície pública são coletados apenas: Força, Posto/Graduação, situação de dependência de filhas e faixa de renda.
                Nenhum dado bancário, prontuário médico ou documento de identificação (RG/CPF) é solicitado no site público.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-neutral-950 border border-amber-900/30 text-xs text-neutral-300 space-y-1">
            <span className="font-mono text-amber-400 font-semibold text-[11px] uppercase block">Contrato de Domínio Neutro:</span>
            <code className="text-neutral-400 text-[11px] font-mono">
              LeadDiagnosticoPublicoContract com ConsentimentoLGPD versionado (src/domain/military-family/types.ts)
            </code>
          </div>
        </div>
      )}
    </div>
  );
};
