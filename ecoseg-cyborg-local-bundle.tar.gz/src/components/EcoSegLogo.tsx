import React from 'react';
import { LogoVariant, BackgroundSurface, SymbolFinish } from '../types/brand';

interface EcoSegLogoProps {
  variant?: LogoVariant;
  surface?: BackgroundSurface;
  finish?: SymbolFinish;
  showGrid?: boolean;
  strokeWidth?: number;
  size?: number;
  tagline?: string;
  className?: string;
  id?: string;
}

export const EcoSegLogo: React.FC<EcoSegLogoProps> = ({
  variant = 'primary',
  surface = 'obsidian',
  finish = 'brass',
  showGrid = false,
  strokeWidth = 2,
  size = 64,
  tagline = 'PLANEJAMENTO & PROTEÇÃO PATRIMONIAL',
  className = '',
  id = 'ecoseg-logo-svg'
}) => {
  // Determine finish colors
  const finishColors: Record<SymbolFinish, { primary: string; secondary: string; glow: string; text: string }> = {
    brass: {
      primary: '#C5A880',
      secondary: '#E2CEB3',
      glow: 'rgba(197, 168, 128, 0.15)',
      text: surface === 'pearl' ? '#18202A' : '#F7F8F9'
    },
    platinum: {
      primary: '#FFFFFF',
      secondary: '#E2E8F0',
      glow: 'rgba(255, 255, 255, 0.1)',
      text: surface === 'pearl' ? '#0F172A' : '#FFFFFF'
    },
    carbon: {
      primary: '#0F172A',
      secondary: '#334155',
      glow: 'rgba(15, 23, 42, 0.08)',
      text: '#0F172A'
    },
    emerald: {
      primary: '#34D399',
      secondary: '#10B981',
      glow: 'rgba(52, 211, 153, 0.15)',
      text: surface === 'pearl' ? '#18202A' : '#F7F8F9'
    }
  };

  const colors = finishColors[finish];

  // The Pure Architectural EcoSeg Symbol (Geometric Horizon & Heritage Monolith)
  // Constructed with golden proportion rectangles and precision circular sectors:
  // 1. Lower solid beam (Fundação / Firmeza de Estado / Segurança Jurídica)
  // 2. Ascending diagonal axis & horizon arch (Compreensão / Visão Ampla de Cenário)
  // 3. Nested concentric curved returns forming 'E' and 'S' flow in architectural balance
  const renderSymbol = (symbolSize: number, customId = 'sym') => (
    <svg
      width={symbolSize}
      height={symbolSize}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="shrink-0 transition-transform duration-300"
      id={`${id}-${customId}`}
    >
      <defs>
        <linearGradient id={`${customId}-brass-grad`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={colors.secondary} />
          <stop offset="50%" stopColor={colors.primary} />
          <stop offset="100%" stopColor={colors.primary} />
        </linearGradient>
        <linearGradient id={`${customId}-axis-grad`} x1="20%" y1="0%" x2="80%" y2="100%">
          <stop offset="0%" stopColor={colors.primary} stopOpacity="0.8" />
          <stop offset="100%" stopColor={colors.secondary} stopOpacity="0.4" />
        </linearGradient>
      </defs>

      {/* Optional Technical Construction Grid */}
      {showGrid && (
        <g stroke="#64748B" strokeWidth="0.5" strokeDasharray="2 2" opacity="0.45">
          {/* Bounding box and safety zone */}
          <rect x="8" y="8" width="84" height="84" />
          <circle cx="50" cy="50" r="42" />
          <circle cx="50" cy="50" r="26" />
          <circle cx="50" cy="50" r="14" />
          {/* Axis guides */}
          <line x1="50" y1="0" x2="50" y2="100" />
          <line x1="0" y1="50" x2="100" y2="50" />
          <line x1="15" y1="85" x2="85" y2="15" stroke="#C5A880" strokeWidth="0.75" />
          <line x1="15" y1="15" x2="85" y2="85" />
          {/* Construction annotations */}
          <text x="12" y="16" fill="#94A3B8" fontSize="4" fontFamily="monospace">Ø 84mm</text>
          <text x="86" y="92" fill="#C5A880" fontSize="4" fontFamily="monospace">Φ 1.618</text>
        </g>
      )}

      {/* Main Vector Geometry: The Horizon & Foundation Pillar */}
      {/* 1. Structural Base Beam (Apoio e Firmeza) */}
      <rect
        x="20"
        y="74"
        width="60"
        height={strokeWidth * 2.8}
        rx={strokeWidth * 0.7}
        fill={`url(#${customId}-brass-grad)`}
      />

      {/* 2. Left Heritage Anchor Column (representing 'E' with architectural capital) */}
      <rect
        x="18"
        y="22"
        width={strokeWidth * 2.8}
        height="53"
        rx={strokeWidth * 0.7}
        fill={`url(#${customId}-brass-grad)`}
      />
      <rect
        x="15.5"
        y="21"
        width={strokeWidth * 4.5}
        height={strokeWidth * 1.5}
        rx="1"
        fill={`url(#${customId}-brass-grad)`}
      />

      {/* 3. Upper Horizon Arch & Aperture (Visão e Compreensão) */}
      <path
        d={`M 20 28 C 20 28, 50 16, 76 28 C 82 31, 82 38, 76 42 C 68 47, 46 47, 36 52 C 26 57, 26 68, 38 72 C 48 75, 68 75, 78 72`}
        stroke={`url(#${customId}-brass-grad)`}
        strokeWidth={strokeWidth * 2.5}
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />

      {/* 4. Central Precision Pivot / Diamond Core (Inteligência & Decisão) */}
      <polygon
        points="50,44 56,50 50,56 44,50"
        fill={colors.secondary}
        opacity="0.9"
      />

      {/* 5. Minimalist Meridian Accent Line */}
      <circle
        cx="72"
        cy="30"
        r={strokeWidth * 0.9}
        fill={colors.primary}
      />
    </svg>
  );

  // Variant 1: Primary Horizontal (Símbolo + Tipografia + Tagline)
  if (variant === 'primary') {
    return (
      <div className={`inline-flex items-center gap-4 ${className}`} id={id}>
        {renderSymbol(size, 'prim')}
        <div className="flex flex-col justify-center">
          <div className="flex items-baseline gap-1.5">
            <span
              className="text-2xl font-bold tracking-[0.16em] leading-none"
              style={{ color: colors.text, fontFamily: 'var(--font-sans)' }}
            >
              ECOSEG
            </span>
          </div>
          <span
            className="text-[9px] tracking-[0.24em] font-medium mt-1 leading-tight uppercase opacity-80"
            style={{ color: finish === 'brass' ? colors.primary : '#94A3B8' }}
          >
            {tagline}
          </span>
        </div>
      </div>
    );
  }

  // Variant 2: Stacked Vertical (Centralizada: Símbolo no topo + EcoSeg + Assinatura)
  if (variant === 'stacked') {
    return (
      <div className={`inline-flex flex-col items-center text-center p-4 ${className}`} id={id}>
        {renderSymbol(size, 'stack')}
        <span
          className="text-3xl font-bold tracking-[0.24em] mt-3 leading-none"
          style={{ color: colors.text, fontFamily: 'var(--font-sans)' }}
        >
          ECOSEG
        </span>
        <div className="w-8 h-[1px] my-2.5 opacity-40" style={{ backgroundColor: colors.primary }} />
        <span
          className="text-[10px] tracking-[0.28em] font-medium leading-tight uppercase opacity-80 max-w-[220px]"
          style={{ color: finish === 'brass' ? colors.primary : '#94A3B8' }}
        >
          {tagline}
        </span>
      </div>
    );
  }

  // Variant 3: Symbol-Only (Monograma isolado para Favicon, App Icon ou Chancela em Relevo)
  if (variant === 'symbol-only') {
    return (
      <div className={`inline-flex items-center justify-center ${className}`} id={id}>
        {renderSymbol(size, 'only')}
      </div>
    );
  }

  // Variant 4: Official Circular Seal (Chancela de Autenticação para Laudos e Certidões)
  if (variant === 'seal') {
    const sealSize = Math.max(size, 140);
    return (
      <div className={`inline-flex items-center justify-center relative ${className}`} id={id}>
        <svg
          width={sealSize}
          height={sealSize}
          viewBox="0 0 200 200"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Outer Ornamental Ring */}
          <circle cx="100" cy="100" r="95" stroke={colors.primary} strokeWidth="1.5" opacity="0.8" />
          <circle cx="100" cy="100" r="91" stroke={colors.primary} strokeWidth="0.75" strokeDasharray="3 3" opacity="0.6" />
          <circle cx="100" cy="100" r="66" stroke={colors.primary} strokeWidth="1" opacity="0.5" />

          {/* Curved Text Path - Top */}
          <path
            id="seal-text-top"
            d="M 28 100 A 72 72 0 0 1 172 100"
            fill="none"
          />
          <text fontSize="8.5" fill={colors.primary} fontWeight="600" letterSpacing="0.28em">
            <textPath href="#seal-text-top" startOffset="50%" textAnchor="middle">
              ECOSEG · INTELIGÊNCIA JURÍDICA
            </textPath>
          </text>

          {/* Curved Text Path - Bottom */}
          <path
            id="seal-text-bottom"
            d="M 172 100 A 72 72 0 0 1 28 100"
            fill="none"
          />
          <text fontSize="8" fill={colors.primary} fontWeight="500" letterSpacing="0.32em">
            <textPath href="#seal-text-bottom" startOffset="50%" textAnchor="middle">
              PLANEJAMENTO PATRIMONIAL MILITAR
            </textPath>
          </text>

          {/* Center Insignia Symbol */}
          <g transform="translate(62, 62) scale(0.76)">
            {/* Structural Base */}
            <rect x="20" y="74" width="60" height="6" rx="1.5" fill={colors.primary} />
            {/* Left Column */}
            <rect x="20" y="22" width="6" height="52" rx="1.5" fill={colors.primary} />
            {/* Curve */}
            <path
              d="M 20 28 C 20 28, 50 16, 76 28 C 82 31, 82 38, 76 42 C 68 47, 46 47, 36 52 C 26 57, 26 68, 38 72 C 48 75, 68 75, 78 72"
              stroke={colors.primary}
              strokeWidth="5"
              strokeLinecap="round"
              fill="none"
            />
            {/* Pivot */}
            <polygon points="50,44 56,50 50,56 44,50" fill={colors.secondary} />
          </g>

          {/* Star Trust Markers */}
          <polygon points="26,100 29,97 32,100 29,103" fill={colors.primary} />
          <polygon points="174,100 171,97 168,100 171,103" fill={colors.primary} />
        </svg>
      </div>
    );
  }

  return null;
};
