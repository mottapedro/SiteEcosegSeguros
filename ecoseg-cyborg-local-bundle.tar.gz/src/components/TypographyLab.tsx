import React, { useState } from 'react';
import { TypoScaleItem } from '../types/brand';
import { Type, Sliders, AlignLeft, Hash } from 'lucide-react';

const TYPO_SCALE: TypoScaleItem[] = [
  {
    level: 'Display Hero',
    element: 'Display / Slide Master',
    sizePx: 38,
    lineHeight: '1.15',
    weight: 'Bold 700 / 800',
    tracking: '-0.02em',
    usage: 'Títulos principais da palestra do João, capas de dossiê executivo e chamada institucional principal da Home.',
    sample: 'Lei nº 13.954/2019 — Perdas e consequências!'
  },
  {
    level: 'H1 Seção',
    element: 'Headline 1',
    sizePx: 28,
    lineHeight: '1.25',
    weight: 'SemiBold 600',
    tracking: '-0.01em',
    usage: 'Abertura dos capítulos da jornada decisória: Patrimônio, Adversidades, Compreensão, Decisão e Proteção.',
    sample: '01. Diagnóstico Estratégico de Lacunas na Pensão'
  },
  {
    level: 'H2 Tópico',
    element: 'Headline 2',
    sizePx: 20,
    lineHeight: '1.35',
    weight: 'SemiBold 600',
    tracking: 'normal',
    usage: 'Subtítulos de laudos, categorias de blindagem e blocos de objeções resolvidas.',
    sample: 'Regras de Transição e Manutenção do Padrão Familiar'
  },
  {
    level: 'Body Text',
    element: 'Parágrafo Consultivo',
    sizePx: 16,
    lineHeight: '1.65',
    weight: 'Regular 400',
    tracking: 'normal',
    usage: 'Pareceres jurídicos, explicações de riscos patrimoniais e fundamentação para pensionistas.',
    sample: 'A recente reforma da proteção social dos militares introduziu novas alíquotas progressivas e descontinuou a integralidade irrestrita para gerações futuras. Sem um instrumento jurídico complementar, o inventário consome até 22% do patrimônio construído.'
  },
  {
    level: 'Data & Tabular',
    element: 'JetBrains Mono Numerais',
    sizePx: 13,
    lineHeight: '1.4',
    weight: 'Medium 500',
    tracking: '+0.04em',
    usage: 'Tabelas comparativas, artigos de lei (Lei nº 13.954/2019), cálculos atuariais e simulações de capital segurado.',
    sample: 'ART. 50-A · R$ 1.850.420,00 · COBERTURA ATUARIAL: 100%'
  }
];

export const TypographyLab: React.FC = () => {
  const [customText, setCustomText] = useState<string>('Segurança Patrimonial para quem dedicou a vida ao Brasil');
  const [fontSize, setFontSize] = useState<number>(32);
  const [letterSpacing, setLetterSpacing] = useState<string>('tracking-tight');
  const [selectedFont, setSelectedFont] = useState<'sans' | 'display'>('sans');

  return (
    <div className="space-y-8">
      {/* Header Statement */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-neutral-800/60">
        <div>
          <span className="text-xs font-semibold tracking-widest text-amber-400/90 uppercase">
            Hierarquia Tipográfica & Editorial
          </span>
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-white mt-1">
            Sistema Tipográfico da EcoSeg
          </h2>
          <p className="text-sm text-neutral-400 mt-1.5 max-w-2xl leading-relaxed">
            Regra 2+1: Um par de fontes refinadas para a comunicação de alta autoridade (<strong>Plus Jakarta Sans</strong> + <strong>Cinzel</strong>)
            mais tipografia monoespelhada para normas jurídicas e cálculos atuariais (<strong>JetBrains Mono</strong>).
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 bg-neutral-900/80 px-3 py-2 rounded-lg border border-neutral-800">
          <span>Anti-Slop: Sem Inter genérico</span>
          <span>·</span>
          <span className="text-amber-400">Kerning Refinado</span>
        </div>
      </div>

      {/* Interactive Type Playground */}
      <div className="p-6 bg-neutral-900/70 border border-neutral-800 rounded-xl space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Type className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white">Bancada de Teste Tipográfico ao Vivo</h3>
          </div>

          <div className="flex items-center gap-3">
            {/* Font family toggle */}
            <div className="flex items-center p-1 bg-neutral-950 rounded-lg border border-neutral-800 text-xs">
              <button
                onClick={() => setSelectedFont('sans')}
                className={`px-3 py-1 rounded font-medium transition-colors cursor-pointer ${
                  selectedFont === 'sans' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Plus Jakarta Sans
              </button>
              <button
                onClick={() => setSelectedFont('display')}
                className={`px-3 py-1 rounded font-medium transition-colors cursor-pointer ${
                  selectedFont === 'display' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Cinzel (Cerimonial)
              </button>
            </div>

            {/* Letter spacing selector */}
            <select
              value={letterSpacing}
              onChange={(e) => setLetterSpacing(e.target.value)}
              className="bg-neutral-950 border border-neutral-700 text-neutral-200 text-xs rounded px-2.5 py-1.5 cursor-pointer"
            >
              <option value="tracking-tighter">Tracking Muito Justo</option>
              <option value="tracking-tight">Tracking Justo (-0.02em)</option>
              <option value="tracking-normal">Tracking Normal</option>
              <option value="tracking-wide">Tracking Amplo (+0.02em)</option>
              <option value="tracking-[0.2em]">Editorial Expandido (+0.2em)</option>
            </select>
          </div>
        </div>

        {/* Text Area for Real Testing */}
        <div className="space-y-2">
          <label className="text-xs text-neutral-400">Texto Editável de Teste:</label>
          <input
            type="text"
            value={customText}
            onChange={(e) => setCustomText(e.target.value)}
            className="w-full px-4 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-sm text-neutral-100 focus:outline-none focus:border-amber-400"
          />
        </div>

        {/* Live Preview Display */}
        <div className="p-8 bg-[#080D14] rounded-lg border border-neutral-800/80 min-h-[140px] flex items-center justify-center text-center">
          <p
            className={`transition-all duration-200 ${letterSpacing} ${
              selectedFont === 'display' ? 'font-serif text-amber-200' : 'text-white'
            }`}
            style={{ fontSize: `${fontSize}px`, lineHeight: 1.25 }}
          >
            {customText}
          </p>
        </div>

        {/* Size Slider */}
        <div className="flex items-center gap-4 text-xs text-neutral-400 pt-1">
          <span className="shrink-0">Tamanho da Fonte:</span>
          <input
            type="range"
            min="16"
            max="56"
            value={fontSize}
            onChange={(e) => setFontSize(parseInt(e.target.value))}
            className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
          />
          <span className="font-mono text-amber-400 w-12 text-right">{fontSize}px</span>
        </div>
      </div>

      {/* Systematic Typography Scale */}
      <div className="space-y-4">
        <h3 className="text-sm font-semibold tracking-wider text-neutral-300 uppercase">
          Escala Tipográfica & Casos de Uso
        </h3>

        <div className="divide-y divide-neutral-800/80 bg-neutral-900/50 border border-neutral-800 rounded-xl overflow-hidden">
          {TYPO_SCALE.map((item, index) => (
            <div key={index} className="p-5 hover:bg-neutral-900/80 transition-colors">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-baseline">
                {/* Meta info column */}
                <div className="lg:col-span-3 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-amber-400">{item.level}</span>
                    <span className="text-[11px] font-mono text-neutral-500">({item.sizePx}px)</span>
                  </div>
                  <p className="text-[11px] text-neutral-400 leading-snug">{item.usage}</p>
                  <div className="text-[10px] font-mono text-neutral-500 pt-1">
                    <span>Peso: {item.weight}</span> · <span>LH: {item.lineHeight}</span>
                  </div>
                </div>

                {/* Sample rendering */}
                <div className="lg:col-span-9 pl-0 lg:pl-4">
                  <div
                    className={`${
                      item.level.includes('Data')
                        ? 'font-mono text-amber-300 tracking-wider'
                        : 'text-neutral-100 font-semibold'
                    }`}
                    style={{
                      fontSize: `${item.sizePx}px`,
                      lineHeight: item.lineHeight
                    }}
                  >
                    {item.sample}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
