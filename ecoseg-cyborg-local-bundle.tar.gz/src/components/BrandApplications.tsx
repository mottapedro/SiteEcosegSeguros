import React, { useState } from 'react';
import { SlideItem } from '../types/brand';
import {
  Presentation,
  FileText,
  Award,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  CheckCircle2,
  Download,
  Play,
  BookOpen,
  UploadCloud,
  RotateCcw,
  Sparkles,
  HeartPulse,
  Globe,
  TrendingUp,
  ArrowUpRight,
  Shield
} from 'lucide-react';
import { EcoSegLogo } from './EcoSegLogo';
import { generatePptx, LECTURE_FULL_SLIDES, SlideData } from '../services/pptxGenerator';
import { generatePdf } from '../services/pdfGenerator';
import { RehearsalModal } from './RehearsalModal';
import { PptImporterModal } from './PptImporterModal';

const LECTURE_SLIDES: SlideItem[] = LECTURE_FULL_SLIDES.map((s, idx) => ({
  id: idx + 1,
  act: s.act,
  title: s.title,
  subtitle: s.subtitle,
  kicker: s.kicker,
  points: s.points,
  citation: s.citation,
  metric: s.metric
}));

export const BrandApplications: React.FC = () => {
  const [activeSlideIndex, setActiveSlideIndex] = useState<number>(0);
  const [isSlideFullscreen, setIsSlideFullscreen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'stationery' | 'lecture' | 'dossier'>('lecture');
  const [isRehearsalOpen, setIsRehearsalOpen] = useState<boolean>(false);
  const [isImporterOpen, setIsImporterOpen] = useState<boolean>(false);
  const [isGeneratingPptx, setIsGeneratingPptx] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState<boolean>(false);
  const [downloadPdfSuccess, setDownloadPdfSuccess] = useState<boolean>(false);
  const [importedSlides, setImportedSlides] = useState<SlideData[] | null>(null);

  const effectiveSlides: SlideItem[] = importedSlides
    ? importedSlides.map((s, idx) => ({
        id: idx + 1,
        act: s.act,
        title: s.title,
        subtitle: s.subtitle,
        kicker: s.kicker,
        points: s.points,
        citation: s.citation,
        metric: s.metric
      }))
    : LECTURE_SLIDES;

  const handleDownloadPptx = async () => {
    try {
      setIsGeneratingPptx(true);
      await generatePptx(importedSlides || undefined);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3500);
    } catch (err) {
      console.error('Erro gerando PPTX:', err);
    } finally {
      setIsGeneratingPptx(false);
    }
  };

  const handleDownloadPdf = async () => {
    try {
      setIsGeneratingPdf(true);
      await generatePdf(importedSlides || undefined);
      setDownloadPdfSuccess(true);
      setTimeout(() => setDownloadPdfSuccess(false), 3500);
    } catch (err) {
      console.error('Erro gerando PDF:', err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const currentSlide = effectiveSlides[activeSlideIndex] || effectiveSlides[0];

  return (
    <div className="space-y-10">
      {/* Header Statement */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-neutral-800/60">
        <div>
          <span className="text-xs font-semibold tracking-widest text-amber-400/90 uppercase">
            Aplicações no Mundo Real
          </span>
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-white mt-1">
            Da Papelaria Nobre ao Telão da Palestra
          </h2>
          <p className="text-sm text-neutral-400 mt-1.5 max-w-2xl leading-relaxed">
            A identidade visual ganha vida nos momentos decisivos de contato: a apresentação do João no auditório militar,
            o dossiê executivo entregue ao oficial e os cartões institucionais com acabamento artesanal.
          </p>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded-lg">
          <button
            onClick={() => setActiveTab('lecture')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
              activeTab === 'lecture' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Palestra Militar (16:9)
          </button>
          <button
            onClick={() => setActiveTab('stationery')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
              activeTab === 'stationery' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Papelaria Institucional
          </button>
          <button
            onClick={() => setActiveTab('dossier')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
              activeTab === 'dossier' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Dossiê de Diagnóstico
          </button>
        </div>
      </div>

      {/* Main Interactive Showcase */}
      {activeTab === 'lecture' && (
        <div className="space-y-6">
          {/* Lecture Stage Context Banner */}
          <div className="relative rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-950 aspect-[16/7] md:aspect-[16/6] max-h-[380px] shadow-2xl">
            <img
              src="/src/assets/images/ecoseg_lecture_stage_1790122412798.jpg"
              alt="Auditório da Palestra EcoSeg"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover opacity-60"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#080D14] via-[#080D14]/60 to-transparent flex flex-col justify-end p-6 md:p-8">
              <div className="max-w-2xl space-y-2">
                <span className="text-[11px] font-mono tracking-widest text-amber-400 uppercase">
                  Clube dos Taifeiros da Aeronáutica (CTA) · 21 de Outubro de 2026
                </span>
                <h3 className="text-xl md:text-2xl font-bold text-white tracking-tight">
                  Palestra João Brito: Lei nº 13.954/2019 — Perdas e consequências!
                </h3>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  Apoio institucional: Pres. Jorge Salustiano Lins e Vice-Pres. Sergio Menezes. Análise técnica e responsável sobre pensões, FUNSA (Tema 1.080 do STJ), filhas de militares e planejamento financeiro.
                </p>
              </div>
            </div>
          </div>

          {/* Interactive Slide Viewer (16:9 Presentation Frame) */}
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-neutral-800/80">
              <div className="flex items-center gap-2">
                <Presentation className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-semibold text-white uppercase tracking-wider">
                  Navegador de Slides da Palestra ({activeSlideIndex + 1} de {effectiveSlides.length})
                </span>
              </div>

              {/* Action Buttons: Import PPT, Ensaio & Download PPTX */}
              <div className="flex items-center flex-wrap gap-2">
                <button
                  onClick={() => setIsImporterOpen(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 text-xs font-semibold cursor-pointer transition-colors"
                  title="Subir arquivo .PPTX ou colar tópicos para estilizar na marca EcoSeg"
                >
                  <UploadCloud className="w-3.5 h-3.5 text-amber-400" />
                  <span>Inserir / Carregar PPT</span>
                </button>

                <button
                  onClick={() => setIsRehearsalOpen(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/40 text-xs font-semibold cursor-pointer transition-colors"
                >
                  <Play className="w-3.5 h-3.5 fill-emerald-300" />
                  <span>Modo Ensaio</span>
                </button>

                <button
                  onClick={handleDownloadPptx}
                  disabled={isGeneratingPptx}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-semibold cursor-pointer transition-colors shadow-sm disabled:opacity-50"
                >
                  {isGeneratingPptx ? (
                    <>
                      <span className="w-3 h-3 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
                      <span>Gerando...</span>
                    </>
                  ) : downloadSuccess ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-900" />
                      <span>Baixado!</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5" />
                      <span>Baixar PPTX</span>
                    </>
                  )}
                </button>

                <button
                  onClick={handleDownloadPdf}
                  disabled={isGeneratingPdf}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white border border-neutral-700 text-xs font-semibold cursor-pointer transition-colors shadow-sm disabled:opacity-50"
                  title="Baixar apresentação completa em formato PDF (16:9)"
                >
                  {isGeneratingPdf ? (
                    <>
                      <span className="w-3 h-3 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                      <span>Gerando PDF...</span>
                    </>
                  ) : downloadPdfSuccess ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>PDF Baixado!</span>
                    </>
                  ) : (
                    <>
                      <FileText className="w-3.5 h-3.5 text-amber-400" />
                      <span>Baixar PDF</span>
                    </>
                  )}
                </button>

                <div className="flex items-center gap-1 ml-1 border-l border-neutral-800 pl-2">
                  <button
                    onClick={() => setActiveSlideIndex(prev => Math.max(0, prev - 1))}
                    disabled={activeSlideIndex === 0}
                    className="p-1.5 rounded-lg border border-neutral-800 text-neutral-400 hover:text-white disabled:opacity-30 cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setActiveSlideIndex(prev => Math.min(effectiveSlides.length - 1, prev + 1))}
                    disabled={activeSlideIndex === effectiveSlides.length - 1}
                    className="p-1.5 rounded-lg border border-neutral-800 text-neutral-400 hover:text-white disabled:opacity-30 cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Imported Presentation Alert Banner */}
            {importedSlides && (
              <div className="flex items-center justify-between p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs">
                <div className="flex items-center gap-2 text-amber-300">
                  <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>
                    <strong>Apresentação Personalizada Ativa:</strong> {importedSlides.length} slides integrados ao contexto e à identidade visual da EcoSeg.
                  </span>
                </div>
                <button
                  onClick={() => {
                    setImportedSlides(null);
                    setActiveSlideIndex(0);
                  }}
                  className="flex items-center gap-1 text-[11px] text-neutral-400 hover:text-white cursor-pointer underline shrink-0 ml-3"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Restaurar Apresentação Padrão</span>
                </button>
              </div>
            )}

            {/* The Slide Canvas (16:9 aspect) */}
            <div className="relative aspect-[16/9] w-full rounded-xl border border-neutral-800/80 bg-[#080D14] overflow-hidden p-6 md:p-12 flex flex-col justify-between shadow-2xl">
              {/* Subtle architectural background guides */}
              <div className="absolute top-0 right-0 w-96 h-96 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-amber-500/5 via-transparent to-transparent pointer-events-none" />

              {/* Slide Top Bar */}
              <div className="flex items-center justify-between border-b border-neutral-800/60 pb-4 z-10">
                <EcoSegLogo variant="primary" size={32} finish="brass" tagline="PALESTRA INSTITUCIONAL" />
                <div className="flex items-center gap-3 text-xs font-mono text-neutral-400">
                  <span className="text-amber-400 font-semibold">{currentSlide.act}</span>
                  <span>·</span>
                  <span>{currentSlide.kicker}</span>
                </div>
              </div>

              {/* Slide Main Content */}
              <div className="space-y-4 my-auto z-10 max-w-4xl py-4">
                <h3 className="text-2xl md:text-4xl font-bold text-white tracking-tight leading-tight">
                  {currentSlide.title}
                </h3>
                <p className="text-sm md:text-base text-neutral-300 leading-relaxed">
                  {currentSlide.subtitle}
                </p>

                {/* Key Points or Metrics */}
                <div className="pt-2 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                  <div className={`${currentSlide.metric ? 'md:col-span-8' : 'md:col-span-12'} space-y-2.5`}>
                    {currentSlide.points.map((point, idx) => (
                      <div key={idx} className="flex items-start gap-3 text-xs md:text-sm text-neutral-300">
                        <div className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-2 shrink-0" />
                        <span className="leading-snug">{point}</span>
                      </div>
                    ))}
                  </div>

                  {currentSlide.metric && (
                    <div className="md:col-span-4 p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center space-y-1">
                      <span className="text-3xl md:text-4xl font-mono font-bold text-amber-300 block">
                        {currentSlide.metric.value}
                      </span>
                      <span className="text-[11px] text-neutral-300 leading-tight block">
                        {currentSlide.metric.label}
                      </span>
                    </div>
                  )}
                </div>

                {currentSlide.citation && (
                  <div className="pt-2">
                    <p className="text-xs md:text-sm italic text-amber-200/80 font-serif border-l-2 border-amber-400/60 pl-3">
                      {currentSlide.citation}
                    </p>
                  </div>
                )}
              </div>

              {/* Slide Bottom Bar */}
              <div className="flex items-center justify-between border-t border-neutral-800/60 pt-3 text-[11px] text-neutral-500 z-10">
                <span>EcoSeg Inteligência Jurídica & Patrimonial · Rio de Janeiro</span>
                <span className="font-mono text-neutral-400">0{currentSlide.id} / 0{effectiveSlides.length}</span>
              </div>
            </div>

            {/* Slide Thumbnails Navigation */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 pt-2">
              {effectiveSlides.map((s, idx) => (
                <button
                  key={s.id}
                  onClick={() => setActiveSlideIndex(idx)}
                  className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer ${
                    activeSlideIndex === idx
                      ? 'border-amber-400/80 bg-amber-500/10 text-white'
                      : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <span className="text-[10px] font-mono text-amber-400 block">Slide 0{s.id}</span>
                  <span className="text-xs font-semibold block truncate mt-0.5">{s.title}</span>
                </button>
              ))}
            </div>

            {/* Seção Oficial: Cards de Soluções para Suprir as Perdas da Lei nº 13.954/2019 */}
            <div className="pt-8 border-t border-neutral-800/80 space-y-6">
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
                <div className="space-y-1.5">
                  <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-400/10 text-amber-400 border border-amber-400/30">
                    <Sparkles className="w-3 h-3" />
                    Página da EcoSeg Seguros · Cards do Público
                  </div>
                  <h3 className="text-xl font-bold text-white tracking-tight">
                    Opções de Produtos para Suprir as Ausências de Direitos
                  </h3>
                  <p className="text-xs text-neutral-300 max-w-3xl">
                    Diante do trânsito em julgado e das restrições legais da Lei nº 13.954/2019, apresentamos opções sólidas de seguradoras de primeira linha para proteger o patrimônio e a saúde da família militar.
                  </p>
                </div>
              </div>

              {/* Grid dos 4 Cards de Solução Solicitados */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Card 1: SulAmérica Saúde */}
                <div className="p-5 rounded-2xl bg-gradient-to-b from-[#0D1627] to-[#0A111E] border border-amber-500/20 hover:border-amber-400/50 transition-all shadow-xl flex flex-col justify-between group">
                  <div className="space-y-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                      <HeartPulse className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-semibold block">
                      Substitui FUNSA / SARAM
                    </span>
                    <h4 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors">
                      SulAmérica Saúde & Odonto
                    </h4>
                    <p className="text-xs text-neutral-300 leading-relaxed">
                      Cobertura médica, hospitalar e odontológica completa para dependentes, filhos maiores de 21 anos e cônjuges excluídos do FUNSA pelo Art. 50 do Estatuto dos Militares.
                    </p>
                    <ul className="text-[11px] text-neutral-400 space-y-1 pt-1 border-t border-neutral-800">
                      <li className="flex items-center gap-1.5 text-neutral-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        Rede hospitalar no RJ e Brasil
                      </li>
                      <li className="flex items-center gap-1.5 text-neutral-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        Reembolso ágil de consultas
                      </li>
                    </ul>
                  </div>
                  <div className="pt-4 mt-4 border-t border-neutral-800/80">
                    <button
                      onClick={() => setIsRehearsalOpen(true)}
                      className="w-full py-2 px-3 rounded-lg text-xs font-semibold bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <span>Ver no Roteiro</span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
                    </button>
                  </div>
                </div>

                {/* Card 2: Seguro Saúde Internacional */}
                <div className="p-5 rounded-2xl bg-gradient-to-b from-[#0D1627] to-[#0A111E] border border-amber-500/20 hover:border-amber-400/50 transition-all shadow-xl flex flex-col justify-between group">
                  <div className="space-y-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                      <Globe className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-400 font-semibold block">
                      Para os Mais Exigentes
                    </span>
                    <h4 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors">
                      Saúde Internacional Premium
                    </h4>
                    <p className="text-xs text-neutral-300 leading-relaxed">
                      Atendimento médico-hospitalar global nos maiores centros mundiais de medicina (EUA, Europa e Brasil), repatriação e segunda opinião médica internacional.
                    </p>
                    <ul className="text-[11px] text-neutral-400 space-y-1 pt-1 border-t border-neutral-800">
                      <li className="flex items-center gap-1.5 text-neutral-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        Cobertura hospitalar mundial
                      </li>
                      <li className="flex items-center gap-1.5 text-neutral-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        Sem limite anual para internação
                      </li>
                    </ul>
                  </div>
                  <div className="pt-4 mt-4 border-t border-neutral-800/80">
                    <button
                      onClick={() => setIsRehearsalOpen(true)}
                      className="w-full py-2 px-3 rounded-lg text-xs font-semibold bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <span>Ver no Roteiro</span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
                    </button>
                  </div>
                </div>

                {/* Card 3: Proteção das Filhas & Sucessão Familiar */}
                <div className="p-5 rounded-2xl bg-gradient-to-b from-[#0D1627] to-[#0A111E] border border-amber-500/20 hover:border-amber-400/50 transition-all shadow-xl flex flex-col justify-between group">
                  <div className="space-y-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                      <Shield className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-semibold block">
                      Substitui Pensão das Filhas
                    </span>
                    <h4 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors">
                      Pensão Privada & Vida Familiar
                    </h4>
                    <p className="text-xs text-neutral-300 leading-relaxed">
                      Planejamento financeiro para garantir renda vitalícia ou capital substancial às filhas e dependentes que não têm direito à pensão militar pela MP 2.215-10/01.
                    </p>
                    <ul className="text-[11px] text-neutral-400 space-y-1 pt-1 border-t border-neutral-800">
                      <li className="flex items-center gap-1.5 text-neutral-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        Liquidação em até 72 horas
                      </li>
                      <li className="flex items-center gap-1.5 text-neutral-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        Isento de inventário e impostos
                      </li>
                    </ul>
                  </div>
                  <div className="pt-4 mt-4 border-t border-neutral-800/80">
                    <button
                      onClick={() => setIsRehearsalOpen(true)}
                      className="w-full py-2 px-3 rounded-lg text-xs font-semibold bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <span>Ver no Roteiro</span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
                    </button>
                  </div>
                </div>

                {/* Card 4: Previdência Privada Consultiva & Auditoria Fiscal */}
                <div className="p-5 rounded-2xl bg-gradient-to-b from-[#0D1627] to-[#0A111E] border border-amber-500/20 hover:border-amber-400/50 transition-all shadow-xl flex flex-col justify-between group">
                  <div className="space-y-3">
                    <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                      <TrendingUp className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-purple-400 font-semibold block">
                      Repõe Perdas da Lei 13.954
                    </span>
                    <h4 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors">
                      Previdência & Isenção IR
                    </h4>
                    <p className="text-xs text-neutral-300 leading-relaxed">
                      Recomposição do poder de compra frente à perda do Adicional de 41% (STF 1175), aliada à auditoria de Isenção de Imposto de Renda (Lei nº 7.713/88).
                    </p>
                    <ul className="text-[11px] text-neutral-400 space-y-1 pt-1 border-t border-neutral-800">
                      <li className="flex items-center gap-1.5 text-neutral-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        Recuperação da renda líquida
                      </li>
                      <li className="flex items-center gap-1.5 text-neutral-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        Análise de laudos e moléstias
                      </li>
                    </ul>
                  </div>
                  <div className="pt-4 mt-4 border-t border-neutral-800/80">
                    <button
                      onClick={() => setIsRehearsalOpen(true)}
                      className="w-full py-2 px-3 rounded-lg text-xs font-semibold bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <span>Ver no Roteiro</span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Stationery Collateral Tab */}
      {activeTab === 'stationery' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 rounded-2xl overflow-hidden border border-neutral-800 shadow-2xl bg-neutral-950">
            <img
              src="/src/assets/images/ecoseg_stationery_mockup_1790122402474.jpg"
              alt="Papelaria Institucional EcoSeg"
              referrerPolicy="no-referrer"
              className="w-full h-auto object-cover"
            />
          </div>

          <div className="lg:col-span-5 space-y-5">
            <span className="text-xs font-mono tracking-widest text-amber-400 uppercase">
              Aplicação Impressa Nobre
            </span>
            <h3 className="text-2xl font-bold text-white tracking-tight">
              Papelaria & Cartões de Apresentação Executivos
            </h3>
            <p className="text-sm text-neutral-300 leading-relaxed">
              O primeiro contato com o militar e sua família deve comunicar segurança inquestionável.
              Papel pesado em algodão 350g, gravação em baixo relevo com hot-stamping em dourado latão fosco e tipografia sóbria.
            </p>

            <div className="space-y-3 pt-2">
              <div className="flex items-start gap-3 p-3 bg-neutral-900/60 rounded-lg border border-neutral-800">
                <CheckCircle2 className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                <div>
                  <h4 className="text-xs font-semibold text-white">Cartão de Visitas do Consultor</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Dimensões 85x55mm, acabamento soft-touch preto grafite com relevo seco do monograma.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-neutral-900/60 rounded-lg border border-neutral-800">
                <CheckCircle2 className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                <div>
                  <h4 className="text-xs font-semibold text-white">Papel Timbrado para Laudos e Pareceres</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Formato A4, gramatura 120g, chancela d'água no rodapé para atestar autenticidade do estudo.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-neutral-900/60 rounded-lg border border-neutral-800">
                <CheckCircle2 className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                <div>
                  <h4 className="text-xs font-semibold text-white">Endereçamento Regional</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Correção dos dados fictícios: Base operacional no Rio de Janeiro, com canais de atendimento direto.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Executive Dossier Tab */}
      {activeTab === 'dossier' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 rounded-2xl overflow-hidden border border-neutral-800 shadow-2xl bg-neutral-950">
            <img
              src="/src/assets/images/ecoseg_dossier_folder_1790122422656.jpg"
              alt="Dossiê Executivo de Diagnóstico EcoSeg"
              referrerPolicy="no-referrer"
              className="w-full h-auto object-cover"
            />
          </div>

          <div className="lg:col-span-5 space-y-5">
            <span className="text-xs font-mono tracking-widest text-amber-400 uppercase">
              Documento de Entrega Consultiva
            </span>
            <h3 className="text-2xl font-bold text-white tracking-tight">
              O Dossiê de Diagnóstico Individualizado
            </h3>
            <p className="text-sm text-neutral-300 leading-relaxed">
              O fechamento da consultoria não é uma apólice fria de seguro, mas a entrega de um
              <strong> Dossiê Patrimonial Personalizado</strong> que consolida todas as garantias da família militar.
            </p>

            <div className="space-y-3 pt-2">
              <div className="p-3.5 bg-neutral-900/60 rounded-lg border border-neutral-800">
                <h4 className="text-xs font-semibold text-amber-400">Conteúdo do Dossiê Físico & Digital</h4>
                <ul className="text-xs text-neutral-300 mt-2 space-y-1.5 list-disc list-inside">
                  <li>Laudo de análise de tempo de serviço e pensão instituída</li>
                  <li>Mapeamento de vulnerabilidades sucessórias e inventário</li>
                  <li>Certificado de blindagem patrimonial com autenticação digital</li>
                  <li>Guia de acionamento de emergência 24h para os dependentes</li>
                </ul>
              </div>

              <p className="text-xs text-neutral-400 italic">
                “Apresentado em pasta rígida de couro ecológico azul meia-noite com a nova insígnia gravada a quente.”
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Interactive Rehearsal Studio Modal */}
      <RehearsalModal
        isOpen={isRehearsalOpen}
        onClose={() => setIsRehearsalOpen(false)}
        customSlides={importedSlides || undefined}
      />

      {/* PPT Importer & Context Integrator Modal */}
      <PptImporterModal
        isOpen={isImporterOpen}
        onClose={() => setIsImporterOpen(false)}
        onImportSuccess={(slides) => {
          setImportedSlides(slides);
          setActiveSlideIndex(0);
        }}
      />
    </div>
  );
};
