import React, { useState, useEffect } from 'react';
import {
  FileText,
  FolderGit2,
  CheckCircle2,
  AlertTriangle,
  Edit3,
  Eye,
  Save,
  Copy,
  Download,
  Search,
  BookOpen,
  Scale,
  Shield,
  Layers,
  Sparkles,
  ExternalLink,
  RefreshCw,
  Sliders,
  ChevronRight,
  Info,
  Clock,
  LayoutGrid,
  FileSearch,
  Cpu
} from 'lucide-react';
import { DomainEcosystemPanel } from './DomainEcosystemPanel';

interface DocItem {
  path: string;
  title: string;
  category: string;
  size: number;
  updatedAt: string;
}

const CATEGORIES = [
  'Todos',
  'Ecossistema de Domínio',
  'ADR Arquitetura',
  'Decisão de Marca (ADR-B)',
  'Base Jurídica Governada',
  'Palestra & Requisitos M1',
  'Constituição Digital',
  'Engenharia Web'
] as const;

export const DocsExplorer: React.FC = () => {
  const [docs, setDocs] = useState<DocItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('Todos');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedDocPath, setSelectedDocPath] = useState<string>('domain/ecoseg-domain-ecosystem-intent.md');
  const [docContent, setDocContent] = useState<string>('');
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [copySuccess, setCopySuccess] = useState<boolean>(false);
  const [lastSavedTime, setLastSavedTime] = useState<string>('');
  const [viewMode, setViewMode] = useState<'ecosystem' | 'markdown'>('ecosystem');

  // Fetch list of docs
  const fetchDocsList = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/docs/list');
      if (res.ok) {
        const data = await res.json();
        setDocs(data.docs || []);
      }
    } catch (err) {
      console.error('Falha ao carregar lista de docs:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch content of selected doc
  const fetchDocContent = async (path: string) => {
    try {
      setIsLoading(true);
      const res = await fetch(`/api/docs/content?path=${encodeURIComponent(path)}`);
      if (res.ok) {
        const data = await res.json();
        setDocContent(data.content || '');
      }
    } catch (err) {
      console.error('Falha ao ler conteúdo do doc:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDocsList();
  }, []);

  useEffect(() => {
    if (selectedDocPath) {
      setIsEditing(false);
      fetchDocContent(selectedDocPath);
    }
  }, [selectedDocPath]);

  const handleSaveDoc = async () => {
    try {
      setIsSaving(true);
      const res = await fetch('/api/docs/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          path: selectedDocPath,
          content: docContent,
        }),
      });
      if (res.ok) {
        setSaveSuccess(true);
        setLastSavedTime(new Date().toLocaleTimeString());
        setTimeout(() => setSaveSuccess(false), 3000);
      }
    } catch (err) {
      console.error('Erro salvando documento:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleCopyContent = () => {
    navigator.clipboard.writeText(docContent);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2500);
  };

  const handleDownloadDoc = () => {
    const blob = new Blob([docContent], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const fileName = selectedDocPath.split('/').pop() || 'documento.md';
    link.download = fileName;
    link.click();
    URL.revokeObjectURL(url);
  };

  const filteredDocs = docs.filter((item) => {
    const matchesCategory =
      selectedCategory === 'Todos' || item.category === selectedCategory;
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.path.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const selectedDocMeta = docs.find((d) => d.path === selectedDocPath);

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      {/* Synchronization Banner with OneDrive / Local Folder */}
      <div className="bg-gradient-to-r from-[#0C1523] via-[#0E1A2D] to-[#0A121F] border border-amber-500/30 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Sincronizado & Ativo
              </span>
              <span className="text-xs text-neutral-400">
                43 Documentos & Decisões Mapeadas
              </span>
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              <FolderGit2 className="w-6 h-6 text-amber-400" />
              Central de Documentação & Governança de ADRs
            </h2>
            <p className="text-sm text-neutral-300 font-mono text-xs flex items-center gap-2 bg-neutral-900/60 px-3 py-1.5 rounded-lg border border-neutral-800 w-fit">
              <span className="text-amber-400">Origem:</span> C:\Users\ATI\OneDrive\Projeto Ecoseg\SiteEcoseg / GitHub mottapedro/SiteEcosegSeguros
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => {
                setSelectedDocPath('adr/0005-ecoseg-public-site-cyborg-consulting-platform.md');
                setSelectedCategory('ADR Arquitetura');
              }}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-amber-400 text-neutral-950 hover:bg-amber-300 transition-colors shadow-lg shadow-amber-400/20 flex items-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Editar ADR 0005
            </button>
            <button
              onClick={() => {
                setSelectedDocPath('legal/MIL-REM-001.md');
                setSelectedCategory('Base Jurídica Governada');
              }}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 transition-colors flex items-center gap-2 cursor-pointer"
            >
              <Scale className="w-3.5 h-3.5 text-blue-400" />
              Lei nº 13.954/2019
            </button>
            <button
              onClick={fetchDocsList}
              title="Recarregar lista de documentos"
              className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 border border-neutral-700 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Switcher de Visão: Ecossistema de Domínio vs Editor/Leitor Markdown */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-neutral-800/80 pb-3">
        <div className="flex items-center gap-2 bg-neutral-900/90 p-1 rounded-xl border border-neutral-800">
          <button
            onClick={() => setViewMode('ecosystem')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              viewMode === 'ecosystem'
                ? 'bg-amber-400 text-neutral-950 shadow-md shadow-amber-400/20'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Cpu className="w-4 h-4" />
            <span>Ecossistema de Domínio & 8 Problemas</span>
          </button>
          <button
            onClick={() => setViewMode('markdown')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              viewMode === 'markdown'
                ? 'bg-amber-400 text-neutral-950 shadow-md shadow-amber-400/20'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <FileSearch className="w-4 h-4" />
            <span>Explorador de Arquivos & Editor ({docs.length} Docs)</span>
          </button>
        </div>

        {viewMode === 'ecosystem' && (
          <button
            onClick={() => {
              setSelectedDocPath('domain/ecoseg-domain-ecosystem-intent.md');
              setViewMode('markdown');
            }}
            className="text-xs text-amber-400 hover:underline flex items-center gap-1.5 cursor-pointer font-medium"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Abrir Documento Markdown de Intenção do Sistema</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {viewMode === 'ecosystem' ? (
        <DomainEcosystemPanel
          onOpenDoc={(path) => {
            setSelectedDocPath(path);
            setViewMode('markdown');
          }}
        />
      ) : (
        <>
          {/* ADR 0005 — 7 Foundational Points Snapshot */}
          {selectedDocPath.includes('0005') && (
        <div className="bg-[#0A111C] border border-amber-500/20 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
            <div className="flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              <h3 className="text-sm font-bold tracking-wider uppercase text-amber-300">
                ADR 0005 — Os 7 Pontos de Decisão Arquitetural
              </h3>
            </div>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
              Status: Aceito & Documentado
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
            <div className="p-3 bg-neutral-900/70 border border-neutral-800 rounded-xl space-y-1">
              <span className="text-amber-400 font-bold">1. Site Público ECOSEG</span>
              <p className="text-neutral-300">
                Permanece no repo público: Home, vertical militar, página /palestra, modo apresentação e diagnóstico educativo leve.
              </p>
            </div>
            <div className="p-3 bg-neutral-900/70 border border-neutral-800 rounded-xl space-y-1">
              <span className="text-amber-400 font-bold">2. SaaS Cyborg Intelligence</span>
              <p className="text-neutral-300">
                Propriedade exclusiva da Cyborg Tecnologia: motor de aderência determinístico, base jurídica versionada e CRM consultivo.
              </p>
            </div>
            <div className="p-3 bg-neutral-900/70 border border-neutral-800 rounded-xl space-y-1">
              <span className="text-amber-400 font-bold">3. Rota & Modo da Palestra</span>
              <p className="text-neutral-300">
                Rota oficial <code className="text-amber-300">/palestra/protecao-familia-militar</code> com 6 funções narrativas (M1-R03).
              </p>
            </div>
            <div className="p-3 bg-neutral-900/70 border border-neutral-800 rounded-xl space-y-1">
              <span className="text-amber-400 font-bold">4. Governança Jurídica</span>
              <p className="text-neutral-300">
                Word do João tratado como inventário bruto; somente normas com validação em fontes oficiais (Planalto/STF) são publicadas.
              </p>
            </div>
            <div className="p-3 bg-neutral-900/70 border border-neutral-800 rounded-xl space-y-1">
              <span className="text-amber-400 font-bold">5. Diagnóstico & Consultor</span>
              <p className="text-neutral-300">
                Coleta inicial de baixa sensibilidade para qualificar interesse; encaminha com segurança para fila de atendimento.
              </p>
            </div>
            <div className="p-3 bg-neutral-900/70 border border-neutral-800 rounded-xl space-y-1">
              <span className="text-amber-400 font-bold">6. LGPD & Minimização</span>
              <p className="text-neutral-300">
                Consentimento explícito, finalidade clara, prazo de retenção e aviso de privacidade prévio a qualquer envio de lead.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Main Explorer Layout: Left Tree + Right Editor/Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Categories and Document List (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          {/* Search box */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400" />
            <input
              type="text"
              placeholder="Buscar documento ou ADR..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#0C121D] border border-neutral-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500/50"
            />
          </div>

          {/* Categories pills */}
          <div className="flex flex-wrap gap-1.5">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-amber-400/20 text-amber-300 border border-amber-500/40'
                    : 'bg-neutral-900 text-neutral-400 border border-neutral-800 hover:text-neutral-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Docs List */}
          <div className="bg-[#0C121D] border border-neutral-800 rounded-2xl overflow-hidden divide-y divide-neutral-800/60 max-h-[600px] overflow-y-auto">
            {filteredDocs.length === 0 ? (
              <div className="p-8 text-center text-xs text-neutral-500">
                Nenhum documento encontrado para os filtros selecionados.
              </div>
            ) : (
              filteredDocs.map((doc) => {
                const isSelected = doc.path === selectedDocPath;
                return (
                  <button
                    key={doc.path}
                    onClick={() => setSelectedDocPath(doc.path)}
                    className={`w-full text-left p-3.5 transition-colors flex items-start gap-3 cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/10 border-l-2 border-amber-400 text-white'
                        : 'hover:bg-neutral-800/40 text-neutral-300'
                    }`}
                  >
                    <FileText
                      className={`w-4 h-4 mt-0.5 shrink-0 ${
                        isSelected ? 'text-amber-400' : 'text-neutral-500'
                      }`}
                    />
                    <div className="min-w-0 flex-1 space-y-1">
                      <div className="text-xs font-semibold leading-snug line-clamp-2">
                        {doc.title}
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-neutral-400">
                        <span className="font-mono">{doc.path}</span>
                        <span>•</span>
                        <span>{(doc.size / 1024).toFixed(1)} KB</span>
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Viewer / Editor (8 cols) */}
        <div className="lg:col-span-8 bg-[#0C121D] border border-neutral-800 rounded-2xl overflow-hidden flex flex-col shadow-2xl">
          {/* Header of Viewer */}
          <div className="bg-neutral-900/90 border-b border-neutral-800 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-amber-400/90">
                  {selectedDocPath}
                </span>
                {saveSuccess && (
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Salvo com sucesso! ({lastSavedTime})
                  </span>
                )}
              </div>
              <h3 className="text-base font-bold text-white">
                {selectedDocMeta?.title || selectedDocPath}
              </h3>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsEditing(!isEditing)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  isEditing
                    ? 'bg-amber-400 text-neutral-950 hover:bg-amber-300'
                    : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                {isEditing ? (
                  <>
                    <Eye className="w-3.5 h-3.5" /> Ver Formatado
                  </>
                ) : (
                  <>
                    <Edit3 className="w-3.5 h-3.5" /> Editar Documento
                  </>
                )}
              </button>

              {isEditing && (
                <button
                  onClick={handleSaveDoc}
                  disabled={isSaving}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-neutral-950 transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  {isSaving ? 'Salvando...' : 'Salvar Alterações'}
                </button>
              )}

              <button
                onClick={handleCopyContent}
                className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors cursor-pointer"
                title="Copiar Markdown"
              >
                {copySuccess ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </button>

              <button
                onClick={handleDownloadDoc}
                className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors cursor-pointer"
                title="Baixar arquivo .md"
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Content Area */}
          <div className="p-6">
            {isLoading ? (
              <div className="py-20 text-center text-xs text-neutral-500 flex flex-col items-center gap-2">
                <RefreshCw className="w-5 h-5 animate-spin text-amber-400" />
                Carregando documento...
              </div>
            ) : isEditing ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs text-neutral-400 bg-neutral-950 px-3 py-2 rounded-lg border border-neutral-800">
                  <span className="flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5 text-amber-400" />
                    Você está editando o arquivo no servidor em formato Markdown puro. Clique em &quot;Salvar Alterações&quot; para gravar.
                  </span>
                  <span>{docContent.length} caracteres</span>
                </div>
                <textarea
                  value={docContent}
                  onChange={(e) => setDocContent(e.target.value)}
                  className="w-full h-[540px] bg-neutral-950 text-neutral-200 font-mono text-xs p-4 rounded-xl border border-neutral-800 focus:outline-none focus:border-amber-500/50 resize-y leading-relaxed"
                />
              </div>
            ) : (
              <div className="prose prose-invert max-w-none text-neutral-200 text-xs sm:text-sm leading-relaxed overflow-x-auto max-h-[600px] overflow-y-auto pr-2">
                <pre className="bg-neutral-950/70 p-4 rounded-xl border border-neutral-800/80 font-mono text-xs whitespace-pre-wrap leading-relaxed text-neutral-300">
                  {docContent}
                </pre>
              </div>
            )}
          </div>
        </div>
      </div>
        </>
      )}
    </div>
  );
};
