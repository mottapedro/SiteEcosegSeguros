import React, { useState, useRef } from 'react';
import { parsePptxFile, parseRawTextToSlides } from '../services/pptxParser';
import { parsePdfFile } from '../services/pdfParser';
import { SlideData } from '../services/pptxGenerator';
import {
  X,
  UploadCloud,
  FileText,
  CheckCircle2,
  AlertCircle,
  FileCode,
  ArrowRight,
  Sparkles,
  Download
} from 'lucide-react';

interface PptImporterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportSuccess: (slides: SlideData[]) => void;
}

export const PptImporterModal: React.FC<PptImporterModalProps> = ({
  isOpen,
  onClose,
  onImportSuccess
}) => {
  const [importMode, setImportMode] = useState<'upload' | 'paste'>('upload');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [importedSlides, setImportedSlides] = useState<SlideData[] | null>(null);
  const [rawText, setRawText] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMessage(null);
    setIsProcessing(true);

    try {
      const fileNameLower = file.name.toLowerCase();
      if (fileNameLower.endsWith('.pdf')) {
        const slides = await parsePdfFile(file);
        if (slides.length === 0) {
          throw new Error('Nenhuma página de texto pôde ser extraída do arquivo PDF.');
        }
        setImportedSlides(slides);
      } else if (fileNameLower.endsWith('.pptx')) {
        const slides = await parsePptxFile(file);
        if (slides.length === 0) {
          throw new Error('Nenhum slide com texto pôde ser extraído do arquivo PPTX.');
        }
        setImportedSlides(slides);
      } else {
        throw new Error('Formato não reconhecido. Por favor selecione um arquivo PDF (.pdf) ou PowerPoint (.pptx). Se o arquivo for .ppt antigo, copie os textos e use a aba "Colar Conteúdo".');
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Erro ao processar o arquivo.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleParseText = () => {
    if (!rawText.trim()) {
      setErrorMessage('Por favor, cole o texto ou tópicos dos slides.');
      return;
    }

    setErrorMessage(null);
    const slides = parseRawTextToSlides(rawText);
    if (slides.length === 0) {
      setErrorMessage('Não foi possível identificar a divisão dos slides. Separe os slides com "---" ou "Slide 1", "Slide 2".');
      return;
    }

    setImportedSlides(slides);
  };

  const handleApplyToContext = () => {
    if (importedSlides && importedSlides.length > 0) {
      onImportSuccess(importedSlides);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-neutral-800 bg-neutral-950/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/10 rounded-lg text-amber-400 border border-amber-500/20">
              <UploadCloud className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono tracking-widest text-amber-400 uppercase">
                Integração de Apresentação
              </span>
              <h3 className="text-base font-bold text-white">
                Inserir PPT no Contexto da EcoSeg
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch: Upload File vs Paste Text */}
        <div className="flex items-center gap-2 px-6 pt-4 border-b border-neutral-800 bg-neutral-950/40 text-xs">
          <button
            onClick={() => {
              setImportMode('upload');
              setErrorMessage(null);
            }}
            className={`pb-3 px-2 font-semibold border-b-2 transition-colors cursor-pointer ${
              importMode === 'upload'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Subir Arquivo (PDF ou PPTX)
          </button>
          <button
            onClick={() => {
              setImportMode('paste');
              setErrorMessage(null);
            }}
            className={`pb-3 px-2 font-semibold border-b-2 transition-colors cursor-pointer ${
              importMode === 'paste'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Colar Texto / Roteiro dos Slides
          </button>
        </div>

        {/* Body content */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {errorMessage && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-start gap-2.5 text-xs text-rose-300">
              <AlertCircle className="w-4 h-4 text-rose-400 mt-0.5 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {!importedSlides ? (
            <>
              {importMode === 'upload' && (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-neutral-700 hover:border-amber-400/70 bg-neutral-950/60 rounded-xl p-8 text-center space-y-3 cursor-pointer transition-colors group"
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pptx,.pdf"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <div className="w-12 h-12 rounded-full bg-neutral-800 group-hover:bg-amber-500/20 text-neutral-400 group-hover:text-amber-400 flex items-center justify-center mx-auto transition-colors">
                    <UploadCloud className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-semibold text-white">
                      Clique para selecionar ou arraste o seu arquivo PDF ou PPTX
                    </p>
                    <p className="text-xs text-neutral-400">
                      Suporta apresentações em PDF e PowerPoint (.pptx). Extrai automaticamente títulos, tópicos e estrutura de slides.
                    </p>
                  </div>
                  {isProcessing && (
                    <div className="flex items-center justify-center gap-2 text-xs text-amber-400 pt-2 font-mono">
                      <span className="w-3.5 h-3.5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                      <span>Lendo e analisando os slides do arquivo...</span>
                    </div>
                  )}
                </div>
              )}

              {importMode === 'paste' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>Cole os tópicos dos seus slides:</span>
                    <span className="font-mono text-[11px] text-amber-400">Separe os slides com "---"</span>
                  </div>
                  <textarea
                    rows={8}
                    value={rawText}
                    onChange={(e) => setRawText(e.target.value)}
                    placeholder={`Slide 1: O Futuro da Pensão Militar\nPor que a estabilidade histórica mudou\n- Análise da Lei 13.954/2019\n- Novas contribuições de inativos\n\n---\n\nSlide 2: A Lacuna de Proteção\nO que acontece no inventário\n- Contas bloqueadas por até 18 meses\n- Custos de ITCMD`}
                    className="w-full bg-[#080D14] border border-neutral-800 rounded-xl p-4 text-xs font-mono text-neutral-200 focus:outline-none focus:border-amber-400 leading-relaxed"
                  />
                  <button
                    onClick={handleParseText}
                    className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Analisar & Estruturar Slides
                  </button>
                </div>
              )}
            </>
          ) : (
            /* Preview of Extracted Slides */
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-emerald-500/10 border border-emerald-500/30 p-3 rounded-xl text-xs text-emerald-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="font-semibold">
                    {importedSlides.length} slides extraídos e convertidos com sucesso!
                  </span>
                </div>
                <button
                  onClick={() => setImportedSlides(null)}
                  className="text-neutral-400 hover:text-white underline text-[11px] cursor-pointer"
                >
                  Trocar arquivo
                </button>
              </div>

              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {importedSlides.map((s, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-neutral-950 border border-neutral-800 rounded-lg space-y-1 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-amber-400 font-bold text-[10px]">
                        Slide 0{idx + 1}
                      </span>
                      <span className="text-[10px] text-neutral-500">
                        {s.points.length} pontos identificados
                      </span>
                    </div>
                    <h4 className="font-semibold text-white">{s.title}</h4>
                    {s.subtitle && <p className="text-neutral-400 text-[11px]">{s.subtitle}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950 flex items-center justify-between">
          <p className="text-[11px] text-neutral-400">
            Aplica automaticamente a paleta <strong>Obsidian Navy</strong> e a tipografia <strong>EcoSeg</strong>.
          </p>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
            >
              Cancelar
            </button>

            {importedSlides && (
              <button
                onClick={handleApplyToContext}
                className="flex items-center gap-1.5 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-neutral-950 rounded-lg text-xs font-bold transition-all cursor-pointer shadow-md"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Aplicar ao Contexto da Palestra</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
