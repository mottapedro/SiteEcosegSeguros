import React, { useState } from 'react';
import { Users, BookOpen, MessageSquare, Copy, Check, ChevronRight } from 'lucide-react';

interface Persona {
  rank: string;
  category: string;
  focus: string;
  primaryPain: string;
  coreArgument: string;
  recommendedCTA: string;
}

const MILITARY_PERSONAS: Persona[] = [
  {
    rank: 'Oficiais Generais & Superiores',
    category: 'Oficiais (Gen / Cel / Ten-Cel / Maj)',
    focus: 'Blindagem Sucessória, ITCMD e Governança Familiar',
    primaryPain: 'Construção de patrimônio relevante (imóveis, investimentos) sujeito a inventários lentos e novos tributos sucessórios estaduais.',
    coreArgument: 'A pensão militar tem teto e deduções progressivas; a transmissão de bens imóveis consome até 20% do capital se não houver planejamento de liquidez imediata.',
    recommendedCTA: 'Agendar Avaliação Confidencial de Planejamento Patrimonial'
  },
  {
    rank: 'Capitães, Tenentes & Subtenentes',
    category: 'Oficiais Intermediários e Praças Graduadas',
    focus: 'Invalidez Operacional, Manutenção da Família e Lacunas de Pensão',
    primaryPain: 'Dependência total do soldo ativo; qualquer interrupção súbita afeta diretamente a educação dos filhos e compromissos imobiliários.',
    coreArgument: 'A reforma de 2019 instituiu novas regras de contribuição. Sem uma apólice estruturada com liquidez em 72h, a família enfrenta meses de espera burocrática até a regularização da pensão.',
    recommendedCTA: 'Solicitar Simulação de Benefício para a sua Patente'
  },
  {
    rank: 'Pensionistas e Dependentes',
    category: 'Cônjuges e Pensionistas Militares',
    focus: 'Preservação da Dignidade, Alíquotas e Descontinuidade',
    primaryPain: 'Surpresa com os descontos compulsórios de pensão (10,5% + acréscimos) e o receio de perder o padrão familiar com a ausência do instituidor.',
    coreArgument: 'Compreensão exata dos direitos adquiridos e eliminação de contratos abusivos de seguros consignados que corroem a renda líquida sem oferecer cobertura real.',
    recommendedCTA: 'Receber Diagnóstico Gratuito de Regularidade Previdenciária'
  }
];

export const AudienceAndMessaging: React.FC = () => {
  const [selectedPersonaIndex, setSelectedPersonaIndex] = useState<number>(0);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const selectedPersona = MILITARY_PERSONAS[selectedPersonaIndex];

  const copySnippet = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(id);
    setTimeout(() => setCopiedText(null), 1800);
  };

  return (
    <div className="space-y-10">
      {/* Header Statement */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-neutral-800/60">
        <div>
          <span className="text-xs font-semibold tracking-widest text-amber-400/90 uppercase">
            Matriz de Mensagem & Públicos
          </span>
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-white mt-1">
            Comunicação Segmentada por Perfil Militar
          </h2>
          <p className="text-sm text-neutral-400 mt-1.5 max-w-2xl leading-relaxed">
            A linguagem da EcoSeg respeita a hierarquia, as dores específicas de cada patente e a verdade das famílias militares do Rio de Janeiro e de todo o Brasil.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 bg-neutral-900/80 px-3 py-2 rounded-lg border border-neutral-800">
          <span>LGPD Compliant</span>
          <span>·</span>
          <span className="text-amber-400">Sem Spam / Sem Falsos Telefones</span>
        </div>
      </div>

      {/* The 6-Stage Narrative Framework */}
      <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-6 space-y-4">
        <h3 className="text-base font-semibold text-white">
          A Jornada Narrativa Obrigatória da EcoSeg
        </h3>
        <p className="text-xs text-neutral-400">
          Ordem formal definida no projeto: Nunca vender a proteção antes de o visitante compreender o patrimônio e as adversidades.
        </p>

        <div className="grid grid-cols-2 md:grid-cols-6 gap-2 pt-2">
          {[
            { step: '01', title: 'Patrimônio', desc: 'O que foi conquistado com honra' },
            { step: '02', title: 'Adversidades', desc: 'Mudança jurídica e reformas' },
            { step: '03', title: 'Compreensão', desc: 'A lacuna invisível da pensão' },
            { step: '04', title: 'Decisão', desc: 'Diagnóstico técnico individual' },
            { step: '05', title: 'Proteção', desc: 'Estruturação patrimonial sob medida' },
            { step: '06', title: 'Progresso', desc: 'Tranquilidade para as próximas gerações' },
          ].map((item, idx) => (
            <div
              key={idx}
              className="p-3 bg-neutral-950/80 border border-neutral-800/80 rounded-lg flex flex-col justify-between space-y-2 hover:border-amber-400/40 transition-colors"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-amber-400 font-bold">{item.step}</span>
                <ChevronRight className="w-3 h-3 text-neutral-600" />
              </div>
              <div>
                <h4 className="text-xs font-semibold text-white">{item.title}</h4>
                <p className="text-[10px] text-neutral-400 mt-0.5 leading-snug">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Persona Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Personas List (Left) */}
        <div className="lg:col-span-4 space-y-2">
          <label className="text-xs font-semibold text-neutral-400 uppercase tracking-wider block mb-2">
            Selecione o Perfil Atendido
          </label>
          {MILITARY_PERSONAS.map((p, idx) => (
            <button
              key={idx}
              onClick={() => setSelectedPersonaIndex(idx)}
              className={`w-full p-4 rounded-xl border text-left transition-all cursor-pointer ${
                selectedPersonaIndex === idx
                  ? 'border-amber-400/80 bg-amber-500/10 text-white shadow-lg'
                  : 'border-neutral-800 bg-neutral-900/60 text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <span className="text-[10px] font-mono text-amber-400 block">{p.category}</span>
              <h4 className="text-sm font-semibold text-white mt-0.5">{p.rank}</h4>
              <p className="text-xs text-neutral-400 mt-1 line-clamp-1">{p.focus}</p>
            </button>
          ))}
        </div>

        {/* Persona Details (Right) */}
        <div className="lg:col-span-8 p-6 bg-neutral-900/70 border border-neutral-800 rounded-xl space-y-6">
          <div className="flex items-start justify-between border-b border-neutral-800 pb-4">
            <div>
              <span className="text-[10px] font-mono text-amber-400 uppercase tracking-widest block">
                Diretriz de Discurso & Argumentação
              </span>
              <h3 className="text-xl font-bold text-white mt-1">{selectedPersona.rank}</h3>
              <span className="text-xs text-neutral-400">{selectedPersona.focus}</span>
            </div>

            <button
              onClick={() => copySnippet(`${selectedPersona.rank} - ${selectedPersona.coreArgument}`, 'persona')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-neutral-300 bg-neutral-800 hover:bg-neutral-700 rounded-lg cursor-pointer transition-colors"
            >
              {copiedText === 'persona' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedText === 'persona' ? 'Copiado!' : 'Copiar Argumento'}</span>
            </button>
          </div>

          <div className="space-y-4 text-xs">
            <div className="p-4 bg-neutral-950 rounded-lg border border-neutral-800/80 space-y-1">
              <span className="font-mono text-rose-400 uppercase text-[10px] block">A Dor / O Risco Invisível</span>
              <p className="text-neutral-300 text-sm leading-relaxed">{selectedPersona.primaryPain}</p>
            </div>

            <div className="p-4 bg-neutral-950 rounded-lg border border-neutral-800/80 space-y-1">
              <span className="font-mono text-emerald-400 uppercase text-[10px] block">O Argumento Consultivo EcoSeg</span>
              <p className="text-neutral-300 text-sm leading-relaxed">{selectedPersona.coreArgument}</p>
            </div>

            <div className="p-4 bg-amber-500/10 rounded-lg border border-amber-500/30 space-y-1">
              <span className="font-mono text-amber-400 uppercase text-[10px] block">Chamada para Ação (CTA Respeitosa)</span>
              <p className="text-white font-medium text-sm">{selectedPersona.recommendedCTA}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
