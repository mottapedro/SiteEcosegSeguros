import React, { useState } from 'react';
import { X, Download, Copy, Check, FileCode, CheckCircle2 } from 'lucide-react';

interface BrandBookExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BrandBookExportModal: React.FC<BrandBookExportModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [exportFormat, setExportFormat] = useState<'markdown' | 'json' | 'css'>('markdown');

  if (!isOpen) return null;

  const markdownContent = `# MANUAL DE IDENTIDADE VISUAL & BRANDBOOK · ECOSEG
**Versão:** 1.0 (Conforme ADR 0005)
**Data:** Setembro de 2026
**Operação:** Consultoria Patrimonial e Jurídica para Famílias Militares
**Sede:** Rio de Janeiro / RJ

---

## 1. Posicionamento da Marca
A ECOSEG não é uma corretora de seguros de varejo. É uma consultoria de inteligência jurídico-patrimonial dedicada a militares das Forças Armadas, pensionistas e seus dependentes.

### A Jornada Narrativa
1. **Patrimônio**: Reconhecimento da história e conquistas da família militar.
2. **Adversidades**: A nova realidade jurídica (Lei nº 13.954/2019, alíquotas de inativos, inventário).
3. **Compreensão**: Diagnóstico técnico das lacunas previdenciárias antes de qualquer produto.
4. **Decisão**: Sessão individual e laudo confidencial.
5. **Proteção**: Estruturação jurídica com liquidez em 72h sem inventário.
6. **Progresso**: Sustentabilidade financeira entre gerações.

---

## 2. O Símbolo EcoSeg (Veto aos Clichês)
- **BANIDO:** Ícones de escudos (ShieldCheck), guarda-chuvas, mãos segurando casas ou desenhos infantis.
- **APROVADO:** O Símbolo Geométrico da Viga & Arco de Horizonte.
  - Viga horizontal inferior: Firmeza e Segurança de Estado.
  - Arco superior: Abertura panorâmica e visão de futuro.
  - Núcleo em diamante: Decisão e inteligência estratégica.

---

## 3. Sistema Cromático (Disciplina 60-30-10)
- **Obsidian Navy (60%):** \`#080D14\` (RGB 8, 13, 20 | CMYK 85, 75, 55, 80)
- **Alabaster Pearl (30%):** \`#F8F9FA\` (RGB 248, 249, 250 | CMYK 2, 1, 1, 0)
- **Imperial Brass (10%):** \`#C5A880\` (RGB 197, 168, 128 | CMYK 20, 30, 55, 5)
- **Deep Evergreen Slate:** \`#172820\` (RGB 23, 40, 32 | CMYK 75, 45, 65, 60)
- **Titanium Slate:** \`#64748B\` (RGB 100, 116, 139)

---

## 4. Tipografia Institucional
- **Display & Títulos:** Plus Jakarta Sans Bold (tracking: -0.02em) / Cinzel (Cerimonial)
- **Texto Corrido:** Plus Jakarta Sans Regular (LH: 1.65, medida 65-75ch)
- **Normas Jurídicas e Dados:** JetBrains Mono (Tabular Numerals para artigos de lei e valores)`;

  const jsonContent = JSON.stringify({
    brand: "ECOSEG",
    subheading: "Planejamento & Proteção Patrimonial",
    version: "1.0",
    compliance: "ADR-0005",
    colors: {
      obsidianNavy: { hex: "#080D14", role: "canvas-60" },
      alabasterPearl: { hex: "#F8F9FA", role: "surface-30" },
      imperialBrass: { hex: "#C5A880", role: "accent-10" },
      deepEvergreen: { hex: "#172820", role: "heritage" },
      titaniumSlate: { hex: "#64748B", role: "support" }
    },
    typography: {
      primary: "Plus Jakarta Sans",
      display: "Cinzel",
      mono: "JetBrains Mono"
    },
    governance: {
      bannedSymbols: ["ShieldCheck", "Umbrella", "HouseInHands"],
      approvedSymbol: "Geometric Horizon & Beam Monolith"
    }
  }, null, 2);

  const cssTokens = `:root {
  --ecoseg-canvas: #080D14;
  --ecoseg-surface: #F8F9FA;
  --ecoseg-brass: #C5A880;
  --ecoseg-evergreen: #172820;
  --ecoseg-slate: #64748B;
  
  --font-brand-display: "Plus Jakarta Sans", sans-serif;
  --font-brand-serif: "Cinzel", serif;
  --font-brand-mono: "JetBrains Mono", monospace;
}`;

  const currentContent = exportFormat === 'markdown' ? markdownContent : exportFormat === 'json' ? jsonContent : cssTokens;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const ext = exportFormat === 'markdown' ? 'md' : exportFormat === 'json' ? 'json' : 'css';
    const blob = new Blob([currentContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ecoseg-brandbook.${ext}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-neutral-800 bg-neutral-950/60">
          <div>
            <span className="text-[10px] font-mono tracking-widest text-amber-400 uppercase">Exportação do Brandbook</span>
            <h3 className="text-lg font-bold text-white mt-0.5">Diretrizes da Marca EcoSeg</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Format Switcher */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-neutral-800 bg-neutral-950/40 text-xs">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setExportFormat('markdown')}
              className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                exportFormat === 'markdown' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Markdown (.md)
            </button>
            <button
              onClick={() => setExportFormat('json')}
              className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                exportFormat === 'json' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-neutral-400 hover:text-white'
              }`}
            >
              JSON Tokens
            </button>
            <button
              onClick={() => setExportFormat('css')}
              className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                exportFormat === 'css' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-neutral-400 hover:text-white'
              }`}
            >
              CSS Variables
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1 text-neutral-200 bg-neutral-800 hover:bg-neutral-700 rounded transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copiado!' : 'Copiar'}</span>
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1 text-amber-950 bg-amber-400 hover:bg-amber-300 font-semibold rounded transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Baixar Arquivo</span>
            </button>
          </div>
        </div>

        {/* Content Box */}
        <div className="p-5 flex-1 overflow-y-auto font-mono text-xs text-neutral-300 bg-[#080D14]">
          <pre className="whitespace-pre-wrap leading-relaxed">{currentContent}</pre>
        </div>
      </div>
    </div>
  );
};
