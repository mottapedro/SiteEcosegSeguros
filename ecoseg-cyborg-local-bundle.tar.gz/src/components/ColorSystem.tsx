import React, { useState } from 'react';
import { ColorToken } from '../types/brand';
import { Copy, Check, ShieldAlert, Sparkles } from 'lucide-react';

const BRAND_COLORS: ColorToken[] = [
  {
    id: 'obsidian-navy',
    name: 'Obsidian Navy',
    category: 'primary',
    hex: '#080D14',
    rgb: '8, 13, 20',
    cmyk: '85, 75, 55, 80',
    pantone: 'Black 6 C / 532 C',
    role: 'Canvas Primário (60%)',
    ratio: '60%',
    description: 'Sobriedade, autoridade institucional e respeito ao contexto das Forças Armadas. Fundo master para a aplicação digital e palestras.',
    lightText: true
  },
  {
    id: 'alabaster-pearl',
    name: 'Alabaster Pearl',
    category: 'surface',
    hex: '#F8F9FA',
    rgb: '248, 249, 250',
    cmyk: '2, 1, 1, 0',
    pantone: 'Cool Gray 1 C',
    role: 'Superfícies & Papelaria (30%)',
    ratio: '30%',
    description: 'Textura de papel algodão nobre para laudos periciais, pareceres jurídicos, capas de dossiê e documentação impressa.',
    lightText: false
  },
  {
    id: 'imperial-brass',
    name: 'Imperial Brass',
    category: 'accent',
    hex: '#C5A880',
    rgb: '197, 168, 128',
    cmyk: '20, 30, 55, 5',
    pantone: '465 C / Metallic 871 C',
    role: 'Acento de Distinção (10%)',
    ratio: '10%',
    description: 'Dourado latão sutil que remete às insígnias de honra militar sem ostentação. Usado estritamente em elementos de alta intenção e no monograma.',
    lightText: false
  },
  {
    id: 'evergreen-slate',
    name: 'Deep Evergreen',
    category: 'primary',
    hex: '#172820',
    rgb: '23, 40, 32',
    cmyk: '75, 45, 65, 60',
    pantone: '5535 C',
    role: 'Acento de Patrimônio Duradouro',
    ratio: 'Suporte',
    description: 'A tradução do "Eco" em chave institucional: verde-oliva profundo e perene, simbolizando o ecossistema familiar protegido ao longo de gerações.',
    lightText: true
  },
  {
    id: 'titanium-slate',
    name: 'Titanium Slate',
    category: 'neutral',
    hex: '#64748B',
    rgb: '100, 116, 139',
    cmyk: '55, 40, 30, 15',
    pantone: 'Slate 500',
    role: 'Metadados & Linhas Técnicas',
    ratio: 'Apoio',
    description: 'Neutro estrutural para cotas técnicas, divisores de seção, números tabulares de projeções de pensão e rótulos secundários.',
    lightText: true
  }
];

export const ColorSystem: React.FC = () => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedBg, setSelectedBg] = useState<string>('#080D14');
  const [selectedFg, setSelectedFg] = useState<string>('#C5A880');

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  // Quick helper to calculate luminance and contrast ratio
  const getContrastRatio = (hex1: string, hex2: string) => {
    const getLum = (hex: string) => {
      const rgb = parseInt(hex.slice(1), 16);
      const r = (rgb >> 16) & 0xff;
      const g = (rgb >> 8) & 0xff;
      const b = (rgb >> 0) & 0xff;
      const a = [r, g, b].map(v => {
        v /= 255;
        return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
      });
      return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
    };
    const lum1 = getLum(hex1);
    const lum2 = getLum(hex2);
    const brightest = Math.max(lum1, lum2);
    const darkest = Math.min(lum1, lum2);
    return (brightest + 0.05) / (darkest + 0.05);
  };

  const currentRatio = getContrastRatio(selectedFg, selectedBg).toFixed(2);
  const ratioNum = parseFloat(currentRatio);
  const passesNormalAA = ratioNum >= 4.5;
  const passesNormalAAA = ratioNum >= 7.0;
  const passesLargeAA = ratioNum >= 3.0;

  return (
    <div className="space-y-8">
      {/* Header Statement */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-neutral-800/60">
        <div>
          <span className="text-xs font-semibold tracking-widest text-amber-400/90 uppercase">
            Sistema Cromático Institucional
          </span>
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-white mt-1">
            Paleta de Alta Nobreza & Disciplina 60-30-10
          </h2>
          <p className="text-sm text-neutral-400 mt-1.5 max-w-2xl leading-relaxed">
            Abandono definitivo do azul corporativo genérico e do verde neon promocional.
            A nova paleta EcoSeg estabelece gravidade, respeito às tradições militares e legibilidade impecável para documentos e palestras.
          </p>
        </div>

        {/* 60-30-10 Rule Visual Indicator */}
        <div className="flex items-center gap-1.5 p-2 bg-neutral-900/80 border border-neutral-800 rounded-lg">
          <div className="flex items-center gap-1">
            <span className="w-3 h-3 rounded bg-[#080D14] border border-neutral-700" />
            <span className="text-xs font-mono text-neutral-300">60%</span>
          </div>
          <span className="text-neutral-600 text-xs">/</span>
          <div className="flex items-center gap-1">
            <span className="w-3 h-3 rounded bg-[#F8F9FA] border border-neutral-300" />
            <span className="text-xs font-mono text-neutral-300">30%</span>
          </div>
          <span className="text-neutral-600 text-xs">/</span>
          <div className="flex items-center gap-1">
            <span className="w-3 h-3 rounded bg-[#C5A880]" />
            <span className="text-xs font-mono text-amber-300">10%</span>
          </div>
        </div>
      </div>

      {/* Main Swatches Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {BRAND_COLORS.map((token) => (
          <div
            key={token.id}
            className="group relative bg-neutral-900/70 border border-neutral-800 rounded-xl overflow-hidden flex flex-col transition-all hover:border-neutral-700"
          >
            {/* Color Swatch Surface */}
            <div
              className="h-32 w-full p-4 flex flex-col justify-between relative transition-transform duration-300"
              style={{ backgroundColor: token.hex }}
            >
              <div className="flex items-center justify-between">
                <span
                  className="text-[10px] font-mono uppercase tracking-wider font-semibold px-2 py-0.5 rounded"
                  style={{
                    backgroundColor: token.lightText ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.08)',
                    color: token.lightText ? '#FFFFFF' : '#0F172A'
                  }}
                >
                  {token.role}
                </span>

                <button
                  onClick={() => copyToClipboard(token.hex, token.id)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded bg-black/40 hover:bg-black/60 text-white cursor-pointer"
                  title="Copiar HEX"
                >
                  {copiedId === token.id ? <Check className="w-3 h-3 text-emerald-300" /> : <Copy className="w-3 h-3" />}
                </button>
              </div>

              <div>
                <span
                  className="font-mono text-xs font-bold block"
                  style={{ color: token.lightText ? '#FFFFFF' : '#0F172A' }}
                >
                  {token.hex}
                </span>
              </div>
            </div>

            {/* Token Specifications */}
            <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
              <div>
                <h3 className="text-sm font-semibold text-white">{token.name}</h3>
                <p className="text-xs text-neutral-400 mt-1 leading-relaxed line-clamp-3">
                  {token.description}
                </p>
              </div>

              <div className="space-y-1 pt-2 border-t border-neutral-800/80 text-[11px] font-mono text-neutral-400">
                <div className="flex justify-between">
                  <span className="text-neutral-500">RGB:</span>
                  <span className="text-neutral-300">{token.rgb}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">CMYK:</span>
                  <span className="text-neutral-300">{token.cmyk}</span>
                </div>
                {token.pantone && (
                  <div className="flex justify-between">
                    <span className="text-neutral-500">Pantone:</span>
                    <span className="text-amber-400/90">{token.pantone}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Live WCAG 2.1 Contrast Testing & Validation Suite */}
      <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-6 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-neutral-800">
          <div>
            <h3 className="text-base font-semibold text-white">
              Validador de Contraste & Acessibilidade WCAG 2.1
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              Garantia de legibilidade de normas jurídicas e diagnósticos para veteranos e pensionistas em qualquer dispositivo.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-neutral-400">Texto:</span>
              <select
                value={selectedFg}
                onChange={(e) => setSelectedFg(e.target.value)}
                className="bg-neutral-950 border border-neutral-700 text-neutral-200 text-xs rounded px-2.5 py-1"
              >
                <option value="#C5A880">Imperial Brass (#C5A880)</option>
                <option value="#FFFFFF">Branco Puro (#FFFFFF)</option>
                <option value="#F8F9FA">Alabaster Pearl (#F8F9FA)</option>
                <option value="#64748B">Titanium Slate (#64748B)</option>
                <option value="#080D14">Obsidian Navy (#080D14)</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-neutral-400">Fundo:</span>
              <select
                value={selectedBg}
                onChange={(e) => setSelectedBg(e.target.value)}
                className="bg-neutral-950 border border-neutral-700 text-neutral-200 text-xs rounded px-2.5 py-1"
              >
                <option value="#080D14">Obsidian Navy (#080D14)</option>
                <option value="#F8F9FA">Alabaster Pearl (#F8F9FA)</option>
                <option value="#172820">Evergreen Slate (#172820)</option>
                <option value="#0F172A">Dark Slate (#0F172A)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Dynamic Preview & Contrast Metric */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Ratio Score Card */}
          <div className="lg:col-span-4 p-5 bg-neutral-950/80 border border-neutral-800 rounded-lg space-y-3">
            <div className="flex items-baseline justify-between">
              <span className="text-xs text-neutral-400 font-medium">Razão de Contraste</span>
              <span className="text-3xl font-bold font-mono tracking-tight text-white">
                {currentRatio}:1
              </span>
            </div>

            {/* WCAG Compliance Badges */}
            <div className="space-y-2 pt-2 border-t border-neutral-800/80">
              <div className="flex items-center justify-between text-xs">
                <span className="text-neutral-400">Texto Normal (16px) WCAG AA (≥ 4.5:1)</span>
                <span className={`font-mono font-semibold ${passesNormalAA ? 'text-emerald-400' : 'text-amber-500'}`}>
                  {passesNormalAA ? 'Aprovado' : 'Alerta'}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-neutral-400">Texto Grande (≥ 24px) WCAG AA (≥ 3.0:1)</span>
                <span className={`font-mono font-semibold ${passesLargeAA ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {passesLargeAA ? 'Aprovado' : 'Reprovado'}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-neutral-400">Padrão Ouro Institucional WCAG AAA (≥ 7.0:1)</span>
                <span className={`font-mono font-semibold ${passesNormalAAA ? 'text-emerald-400' : 'text-neutral-500'}`}>
                  {passesNormalAAA ? 'Excelente AAA' : 'Abaixo de 7:1'}
                </span>
              </div>
            </div>
          </div>

          {/* Interactive Visual Sample */}
          <div
            className="lg:col-span-8 p-6 rounded-lg border transition-all duration-200"
            style={{ backgroundColor: selectedBg, borderColor: 'rgba(255,255,255,0.08)' }}
          >
            <div className="space-y-3">
              <span
                className="text-xs font-mono tracking-widest uppercase block opacity-80"
                style={{ color: selectedFg }}
              >
                PROJEÇÃO PATRIMONIAL MILITAR · ART. 50
              </span>
              <h4
                className="text-xl md:text-2xl font-bold tracking-tight"
                style={{ color: selectedFg }}
              >
                Compreensão Prévia das Lacunas na Pensão Militar
              </h4>
              <p
                className="text-sm leading-relaxed max-w-xl opacity-90"
                style={{ color: selectedFg }}
              >
                A nova lei de proteção social alterou as regras de contribuição e transição. Nosso modelo consultivo diagnostica a vulnerabilidade específica de cada dependente antes de propor qualquer estrutura de cobertura.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
