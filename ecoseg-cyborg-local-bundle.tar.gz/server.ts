import dotenv from 'dotenv';
import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';

// Load local env files (.env.local takes precedence over .env).
// In AI Studio these vars are injected at runtime, so this is a no-op there.
dotenv.config({ path: ['.env.local', '.env'] });

let aiClient: GoogleGenAI | null = null;

function getAiClient() {
  if (!aiClient) {
    if (!process.env.GEMINI_API_KEY) {
      throw new Error('GEMINI_API_KEY environment variable is missing');
    }
    // Video generation/editing runs with background:false, so interactions.create
    // blocks until the render finishes (1–3 min). The SDK default timeout is 1 min,
    // which kills longer renders (notably edits) — raise it well above max render time.
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: { timeout: 300000 }, // 5 minutes
    });
  }
  return aiClient;
}

// Product and atmosphere reference images arrive from the client as base64
// (either a selected suggestion or images the user uploaded). Each is forwarded
// straight on to Gemini — the server keeps no image state of its own.
type ImageMime =
  | 'image/png' | 'image/jpeg' | 'image/webp'
  | 'image/heic' | 'image/heif' | 'image/gif' | 'image/bmp' | 'image/tiff';

interface InlineImage {
  data: string;       // base64, without the data: URI prefix
  mimeType: ImageMime;
}

interface GenerateBody {
  productDesc?: string;
  atmosphereDesc?: string;
  productImages?: InlineImage[];
  atmosphereImages?: InlineImage[];
}

// Turns a tiny setting word/phrase ("jungle", "Mediterranean studio") into one
// ~100-word natural-language image prompt for gemini-3.1-flash-lite-image: a clean, empty,
// on-aesthetic product-environment shot with a clear staging surface.
const ATMOSPHERE_DIRECTOR_SYSTEM_INSTRUCTION = `#Your Role

You are an art director, prompt writer and **materials aestheticist** for the Omni product-image flow. A user types a tiny setting input — often a single word. You don't depict the place; you **translate it into premium materials, palette and light**, and return **one natural-language prompt (~100 words)** for the image model that yields a minimal, textural product-photography vignette: a gorgeous surface, simple planes, and clean space for a small product. Elite product-photographer's-portfolio quality.

### The rule that governs everything

**Decode, don't depict.** Read the setting as a cue for materials, color and light — never as a literal scene. "Log cabin" is not a room with furniture; it's warm timber, grain and low sun. Strip away architecture, props, furniture and lifestyle. The *material* is the subject.

### Constant quality core (every image)

- **Photo-real product photography only.** Never anime, illustration, painting, sketch, render-toy, fantasy or graphic-design looks.
- **Real camera:** full-frame digital SLR, 85mm prime, true-to-life colour, exquisite fine texture, shallow depth of field.
- **Tight, textural crop:** move in close on a small, beautiful passage of surface. Short-telephoto compression, soft background fall-off. No wide shots, no rooms, no establishing views.
- **Extreme minimalism:** at most two simple planes (a backdrop and a ground/ledge), or a single surface. Generous negative space. Nothing else in frame.
- **Premium always.** No product, objects, furniture, people, text, logos, household items or clutter. No staging objects or podiums.
- **Open foreground, never a "spot".** Let the surface continue low in the frame as generous, unbroken negative space — calm, soft-focus, uninterrupted. Compose this emptiness as a deliberate aesthetic quality of the photograph. **Never state a purpose for it**, and never describe it as a cleared, polished, wiped, flattened or "reserved" area, or as space "for" anything. A stated purpose makes the model fabricate an artefact — a slip of paper, a placemat, an unnaturally buffed patch. Open, natural surface only.
- Portrait orientation (~4:5).

### Material aestheticist layer (derive, don't default)

- Choose **1–2 premium materials** truly authentic to the setting, paired with a designer's eye. "Premium" = natural, tactile, characterful, beautifully finished, real texture (stone, timber, plaster, marble, linen, metal, water, leaf). Named examples are sparks, **not a menu**; invent freely; always honor a user-named material.
- Build **palette and light** from those materials. One palette, one light direction per image.

### Method (run silently)

1. Decode the setting into 1–2 premium materials, a palette, and a light.
2. Compose a minimal two-plane (or single-surface) vignette, framed tight.
3. Open the foreground into generous negative space — composed for beauty, with no stated purpose.
4. Write the ~100-word prompt.
5. Append the fixed suppression line on its own line (see Output contract).

### Examples (decode demos, not lookups)

- **"log cabin"** → a tight study of warm oak or cedar planks meeting honed travertine, deep timber palette, low raking sun catching the grain — no room, no furniture.
- **"jungle"** → a single broad waxy green leaf against damp dark stone, deep greens, dappled light — a material study, not a scene.
- **"pool"** → sunlit pale stone meeting still water, soft caustics — clean and close, not a resort.

### Output contract

Output **only**, in this order:

1. The ~100-word natural-language paragraph — one real photograph shot tight on an 85mm lens, minimal and textural. The paragraph never mentions products, placement or purpose.
2. A line break.
3. This exact line, verbatim, on its own (not counted toward the ~100 words):

No products in shot. No logos. No product plinth.

No title, notes or quotes. The suppression line is the only place the word "product" appears.`;

// gemini-3.1-flash-lite-image with delivery:'inline' returns image bytes in the response, but
// fall back to downloading the File API uri if a uri ever comes back instead.
async function fileUriToBase64(uri: string): Promise<{ data: string; mimeType: string }> {
  const fileId = uri.match(/files\/([a-zA-Z0-9_-]+)/)?.[1];
  if (!fileId) throw new Error('Could not parse file id from image uri');
  const apiKey = process.env.GEMINI_API_KEY;
  const url = `https://generativelanguage.googleapis.com/v1beta/files/${fileId}:download?alt=media&key=${apiKey}`;
  const upstream = await fetch(url);
  if (!upstream.ok) throw new Error(`Failed to download generated image: ${upstream.statusText}`);
  const buffer = Buffer.from(await upstream.arrayBuffer());
  return { data: buffer.toString('base64'), mimeType: 'image/jpeg' };
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // Endpoint to generate prompt
  app.post('/api/generate-prompt', async (req, res) => {
    try {
      const { productDesc, atmosphereDesc, productImages = [], atmosphereImages = [] }: GenerateBody = req.body;
      const ai = getAiClient();
      const promptWriterSystemInstruction = `## Role
You are an elite product-film director, editor and Gemini Omni prompt engineer in one box. You receive a handful of plain inputs from an everyday seller and return **one flawless, timestamped Omni directive prompt** that yields a premium, short-form product showcase reel built from several shots. You direct like a luxury commercial and cut like a master editor. Your taste *is* the product: restrained, expensive, clarifying. Never slop, never gimmick, never overclaim.

## Inputs you receive
- **1–4 product reference images** — e-commerce style, white background; any mix of front, side, top, detail views.
- **A short product description** — what it is, plus key aesthetic details (plain language).
- **A simple style brief** — often only a few words (e.g. "white studio", "clinical skincare lab"). May include a camera or shot request.
- **Optional extra notes** — treat any later or added input as an override.

## Non-negotiable taste
- Classy, simple, high-end. A tight, deliberate edit where every cut earns its place.
- Forbidden: vulgar, crass, busy, cheap, "AI-looking", frantic over-cutting.
- Premium = restraint and intent: controlled palette, motivated light, real materials behaving correctly, a confident rhythm.

## Format & length
- **~10 seconds total. 2–7 shots.** *You* decide the count for this product — never pad to seven.
- **Each shot = one timestamp.** Beats typically 1–2s; vary deliberately.
- Cut with an editor's eye: hook on frame one, vary scale and angle every cut, end on a held hero the product reads on.

## Omni craft you apply
Levers per shot: **subject · camera framing + motion · style · lighting · location.** Detail buys control; specify deliberately, never bloat.
- **Reference the images.** Lock identity, geometry, proportions, label and material from *all* views. The product never distorts, rebrands, or sprouts features it doesn't have — identity holds across every cut.
- **Camera repertoire.** Draw across shots: "slow push in", "orbit / arc", "macro detail", "rack focus", "top-down reveal", "gentle levitation", "locked off", "static", "dolly", "natural smartphone zoom".
- **Physics & materials.** Omni reasons about gravity, fluids and light. Make glass refract, metal catch a rim, serum bead, powder settle — accurately.
- **World knowledge.** Don't over-explain. State intent and let Omni reason the rest.

## Hard suppressions (always enforce in the output)
- **No music of any kind.** No score, soundtrack, background music, beat, or musical sting — ever.
- **No voice.** No voiceover, narration, dialogue or vocals.
- **No overlaid graphics.** No on-screen text, titles, captions, subtitles, lower thirds, typography, added logos, badges, watermarks or UI. The only text permitted is what physically exists on the product itself.
- **Audio is near-silent:** only very subtle, realistic diegetic sound effects (a faint surface tap, soft glass chime, gentle fabric or air, a single liquid drop). Often barely there.

## Editing patterns (the repertoire)
- **Sequencing:** open with a hook (hero or striking detail) → vary shot scale and angle so each cut feels intentional → match-cut on motion or shape where possible → accent a beat or two → **land on a clean, held hero frame**.
- **Rhythm:** brisk but never frantic; let the final shot breathe ~0.5s longer.
- **Default arc (adapt, don't obey):** hero wide → macro detail → arc → push-in → held hero.

## Method (run silently, then output)
1. **Read the product** — category, material, finish, features most worth showing.
2. **Translate the brief** into a crafted environment, palette and light. Elevate; never literalise crudely.
   - *"white studio"* → seamless cyclorama, soft key, gentle floor gradient, one clean shadow.
   - *"clinical / skincare lab"* → cool neutral palette, glass and brushed chrome, caustic light, one tasteful water / serum motion.
3. **Design the edit** — choose shot count and order; assign each a move that reveals a *real* feature; vary scale.
4. **Time it** across ~10s with editorial rhythm and a held final beat.
5. **Write the directive prompt** per the contract below.

## Output contract
Output **only** the directive prompt — nothing else. No "shot logic" line, no headings, no fences, no explanation before or after. It must begin with the words **"Create a professional product showcase reel"** and read as one clean, paste-ready directive in this shape:

Create a professional product showcase reel of  <product> locked to the reference images so its identity, proportions, label and material stay accurate in every shot. Hard cuts between shots; the product is the hero throughout. Environment: . Grade and mood: premium, calm, confident, with soft motivated lighting that reveals the material truthfully.

0.0–0.0s — .
0.0–0.0s — .
… (2–7 shots, varied in scale and motion) …
0.0–10.0s — .


Materials and physics: <how light and matter behave securely>. Audio: near-silent, only very subtle realistic diegetic sound effects; no music of any kind, no score, no soundtrack, no musical sting, no voiceover, no vocals. No on-screen text, titles, captions, lower thirds, typography, added logos, graphics, watermarks or UI of any kind. Avoid: distorted or rebranded product, invented features, extra props, harsh shadows, over-cutting, frantic pace, cheap gloss.

## Guardrails
- Missing input → make the **smallest premium assumption** and fold it silently into the directive.
- The product is the star; the environment and the edit exist only to serve it.
- Never pad the shot count; fewer, better beats beat seven busy ones.
- Specs (duration, shot ceiling, image count, aspect) are a dated snapshot — defer to any current limits the operator supplies.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: [
          { text: `Product: ${productDesc || '(no description provided — infer from the reference images)'}\nAtmosphere: ${atmosphereDesc || '(no description provided — infer from the reference images)'}\n\nProduct reference images:` },
          ...productImages.map(img => ({ inlineData: { mimeType: img.mimeType, data: img.data } })),
          { text: 'Atmosphere reference images:' },
          ...atmosphereImages.map(img => ({ inlineData: { mimeType: img.mimeType, data: img.data } })),
        ],
        config: { systemInstruction: promptWriterSystemInstruction },
      });

      res.json({ prompt: response.text });
    } catch (e: any) {
      console.error('Error generating prompt:', e);
      res.status(500).json({ error: e.message });
    }
  });

  // Quickly auto-describe an uploaded product/atmosphere in the same voice as the
  // hard-coded examples, so every selection carries a description / style brief.
  app.post('/api/describe', async (req, res) => {
    try {
      const { type, images = [] }: { type?: 'product' | 'atmosphere'; images?: InlineImage[] } = req.body;
      if (images.length === 0) {
        res.status(400).json({ error: 'No images provided' });
        return;
      }
      const ai = getAiClient();

      const productInstruction = `You write ultra-concise product descriptions for a premium product-film tool.
Given product reference image(s), output ONE short description (1–2 sentences, plain language): what the product is, plus its key aesthetic and material details. Match the voice of these examples:
- "An oversized cup holder-friendly mug that comes with the last straw you will ever need."
- "Premium luxury running sneakers. Sculptural modular sole and an upper made out of suede nubuck leather and mesh sculptural panels."
- "A bottle of perfume called 'Nerelle'. The ornate bottle features real stone minerals, sodalite, and malachite."
Output ONLY the description text — no labels, no quotes, no preamble.`;

      const atmosphereInstruction = `You write ultra-concise environment "style briefs" for a premium product-film tool.
Given a reference image of an empty scene or backdrop, output ONE short style brief (1–3 sentences) describing the environment, materials, lighting and mood. Where the product would sit, refer to it as the literal token "the {product_id}" so it can be substituted later. Match the voice of these examples:
- "Minimalist craft luxury. A pristine Carrara marble plinth rests against a soft sage backdrop. Crisp directional sunlight casts soft shadows, creating an earthy yet elevated aesthetic. The {product_id} is seen in perfect detail, conveying texture, calm, and sophisticated gradients."
- "Mediterranean, modern luxury. Warm, porous travertine blocks create a structured geometric podium beneath a brilliant azure sky, presenting the {product_id} perfectly. Soft dappled leaf shadows contrast the sharp architectural lines, evoking a serene, sun-drenched coastal escape."
- "Mediterranean minimalism utilizing a warm sun-drenched, polished plaster corner with a soft rose-tinted floor. Crisp palm frond silhouettes cast dramatic yet serene shadows evoking a premium organic golden-hour mood."
Output ONLY the style brief text — no labels, no quotes, no preamble.`;

      const isAtmosphere = type === 'atmosphere';
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: [
          { text: isAtmosphere ? 'Describe this scene/backdrop as a style brief:' : 'Describe this product:' },
          ...images.map(img => ({ inlineData: { mimeType: img.mimeType, data: img.data } })),
        ],
        config: {
          systemInstruction: isAtmosphere ? atmosphereInstruction : productInstruction,
          maxOutputTokens: 512,
          temperature: 0.7,
        },
      });

      res.json({ description: (response.text || '').trim() });
    } catch (e: any) {
      console.error('Error describing image:', e);
      res.status(500).json({ error: e.message });
    }
  });

  // Generate an atmosphere image from a tiny setting input. Two stages:
  //   1. gemini-3.1-flash-lite expands the input into a ~100-word image prompt.
  //   2. gemini-3.1-flash-lite-image (Nano Banana family) renders the atmosphere from that prompt.
  // Returns the image inline as base64 so it can flow straight into the video
  // pipeline as the atmosphere reference — the user never sees it until it lands
  // in the "sources" strip under the finished video.
  app.post('/api/generate-atmosphere', async (req, res) => {
    try {
      const { input }: { input?: string } = req.body;
      if (!input || !input.trim()) {
        res.status(400).json({ error: 'No atmosphere prompt provided' });
        return;
      }
      const ai = getAiClient();

      // Stage 1 — interpret the user's setting into an on-aesthetic image prompt.
      const promptResponse = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: [{ text: `Setting: ${input.trim()}` }],
        config: {
          systemInstruction: ATMOSPHERE_DIRECTOR_SYSTEM_INSTRUCTION,
          maxOutputTokens: 512,
          temperature: 0.8,
        },
      });
      const imagePrompt = (promptResponse.text || '').trim();
      if (!imagePrompt) throw new Error('Failed to write an atmosphere prompt');

      // Stage 2 — render the atmosphere with gemini-3.1-flash-lite-image (1K is the only
      // supported resolution; portrait 4:5 matches the house aesthetic).
      const interaction = await ai.interactions.create({
        model: 'gemini-3.1-flash-lite-image',
        input: [{ type: 'text', text: imagePrompt }],
        // gemini-3.1-flash-lite-image rejects a `delivery` field and returns the image inline by
        // default. 1K is the only supported resolution; 4:5 matches the house look.
        response_format: { type: 'image', image_size: '1K', aspect_ratio: '4:5', mime_type: 'image/jpeg' },
        store: false,
        background: false,
        stream: false,
      });

      const image = interaction.output_image;
      let data = image?.data;
      let mimeType: string = image?.mime_type || 'image/jpeg';
      if (!data && image?.uri) ({ data, mimeType } = await fileUriToBase64(image.uri));
      if (!data) throw new Error('gemini-3.1-flash-lite-image returned no image');

      res.json({ image: { data, mimeType }, prompt: imagePrompt });
    } catch (e: any) {
      console.error('Error generating atmosphere:', e);
      res.status(500).json({ error: e?.body || e.message });
    }
  });

  // Endpoint to start omni generation
  app.post('/api/generate-video', async (req, res) => {
    try {
      const { prompt, productImages = [], atmosphereImages = [] }: GenerateBody & { prompt?: string } = req.body;
      const ai = getAiClient();

      console.log(`Sending request to Gemini Omni (${productImages.length} product, ${atmosphereImages.length} atmosphere images)...`);

      const interaction = await ai.interactions.create({
        model: 'gemini-omni-1.1-flash',
        input: [
            ...productImages.map(img => ({ type: 'image' as const, data: img.data, mime_type: img.mimeType })),
            ...atmosphereImages.map(img => ({ type: 'image' as const, data: img.data, mime_type: img.mimeType })),
            { type: 'text', text: prompt }
        ],
        response_format: { type: 'video', delivery: 'uri' },
        store: true,
        background: false,
        stream: false
      });

      console.log(`Interaction created: ${interaction.id}`);
      
      // We will do background polling here so we don't hold the HTTP request open if we can avoid it.
      // Or we can just hold it open since EAP allows background: true/false. Actually, for simplicity on MVP, we can return the interaction ID or file ID and let the client explicitly poll us for status.
      
      if (!interaction.output_video || !interaction.output_video.uri) {
        throw new Error('No video URI returned from interaction.');
      }
      
      const fileIdMatch = interaction.output_video.uri.match(/files\/([a-zA-Z0-9_-]+)/);
      const fileId = fileIdMatch ? fileIdMatch[1] : null;

      res.json({ interactionId: interaction.id, uri: interaction.output_video.uri, fileId });
    } catch (e: any) {
      console.error('Error generating video:', e);
      // Try to dump error details closely
      res.status(500).json({ error: e?.body || e.message });
    }
  });

  // Endpoint to edit an existing video via Omni's stateful interaction chaining.
  // No images needed — the model remembers the prior video from previous_interaction_id.
  app.post('/api/edit-video', async (req, res) => {
    try {
      const { previousInteractionId, instructions }: { previousInteractionId?: string; instructions?: string } = req.body;
      if (!previousInteractionId || !instructions) {
        res.status(400).json({ error: 'previousInteractionId and instructions are required' });
        return;
      }
      const ai = getAiClient();

      console.log(`Editing interaction ${previousInteractionId}...`);
      const interaction = await ai.interactions.create({
        model: 'gemini-omni-1.1-flash',
        previous_interaction_id: previousInteractionId,
        input: [{ type: 'text', text: instructions }],
        response_format: { type: 'video', delivery: 'uri' },
        store: true,
        background: false,
        stream: false
      });

      if (!interaction.output_video || !interaction.output_video.uri) {
        throw new Error('No video URI returned from interaction.');
      }

      const fileIdMatch = interaction.output_video.uri.match(/files\/([a-zA-Z0-9_-]+)/);
      const fileId = fileIdMatch ? fileIdMatch[1] : null;

      res.json({ interactionId: interaction.id, uri: interaction.output_video.uri, fileId });
    } catch (e: any) {
      console.error('Error editing video:', e);
      res.status(500).json({ error: e?.body || e.message });
    }
  });

  // Endpoint to poll file status
  app.get('/api/file-status/:fileId', async (req, res) => {
    try {
      const { fileId } = req.params;
      const ai = getAiClient();
      
      const fInfo = await ai.files.get({ name: `files/${fileId}` });
      const state = (fInfo.state as any)?.name || fInfo.state;
      res.json({ state });
    } catch (e: any) {
      console.error('Error getting file status:', e);
      res.status(500).json({ error: e.message });
    }
  });

  // Cache fetched videos in-memory so range requests (seeking) don't re-download
  // the whole file from Google on every scrub. These are short clips.
  const videoCache = new Map<string, Buffer>();

  // Endpoint to proxy the actual video — supports HTTP range requests so the
  // player timeline can seek (browsers require 206 Partial Content for that).
  app.get('/api/video/:fileId', async (req, res) => {
    try {
      const { fileId } = req.params;

      let buffer = videoCache.get(fileId);
      if (!buffer) {
        const apiKey = process.env.GEMINI_API_KEY;
        const url = `https://generativelanguage.googleapis.com/v1beta/files/${fileId}:download?alt=media&key=${apiKey}`;
        const upstream = await fetch(url);
        if (!upstream.ok) {
          return res.status(upstream.status).send(`Failed to fetch video: ${upstream.statusText}`);
        }
        buffer = Buffer.from(await upstream.arrayBuffer());
        if (videoCache.size >= 12) {
          const oldest = videoCache.keys().next().value;
          if (oldest) videoCache.delete(oldest);
        }
        videoCache.set(fileId, buffer);
      }

      const total = buffer.length;
      res.setHeader('Content-Type', 'video/mp4');
      res.setHeader('Accept-Ranges', 'bytes');
      res.setHeader('Cache-Control', 'public, max-age=31536000');

      const range = req.headers.range;
      if (range) {
        const match = /bytes=(\d*)-(\d*)/.exec(range);
        let start = match && match[1] ? parseInt(match[1], 10) : 0;
        let end = match && match[2] ? parseInt(match[2], 10) : total - 1;
        if (Number.isNaN(start)) start = 0;
        if (Number.isNaN(end) || end >= total) end = total - 1;
        if (start > end || start >= total) {
          res.status(416).setHeader('Content-Range', `bytes */${total}`).end();
          return;
        }
        res.status(206);
        res.setHeader('Content-Range', `bytes ${start}-${end}/${total}`);
        res.setHeader('Content-Length', end - start + 1);
        res.end(buffer.subarray(start, end + 1));
      } else {
        res.setHeader('Content-Length', total);
        res.end(buffer);
      }
    } catch (e: any) {
      console.error('Error streaming video:', e);
      res.status(500).send(e.message);
    }
  });

  // User provided endpoints for gemini-3.1-flash-lite-image and gemini-3.1-flash-lite
  app.post("/api/generate", async (req, res) => {
    try {
      const { prompt } = req.body;
      const ai = getAiClient();
      const textResponse = await ai.models.generateContent({
        model: "gemini-3.1-flash-lite",
        contents: prompt,
        config: {
          systemInstruction: "You are an infinite spatial-knowledge-engine generator. Respond to the user's query by generating AI content in a specific JSON format. The format must contain: 'text' (AI-generated explanatory text detailing the topic. Use markdown if necessary, but keep it brief and impactful. CRITICAL: You MUST wrap 2 to 4 key concepts or interesting terms in your text as markdown links using the exact format `[Search Term](Search Term)`, so users can click them to branch off and explore that topic further!), and 'prompts' (an array of exactly 3 string items containing suggested follow-up questions or sub-topics). Keep text concise and informative.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              text: { type: Type.STRING },
              prompts: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: ["text", "prompts"],
          },
        },
      });

      let rawText = textResponse.text || "{}";
      rawText = rawText.replace(/```(json)?/gi, '').trim();
      const responseData = JSON.parse(rawText);
      res.json(responseData);
    } catch (error: any) {
      console.error(error);
      res.status(500).json({ error: "Failed to generate text content." });
    }
  });

  app.post("/api/generate-image", async (req, res) => {
    try {
      const { prompt, imageBase64, type } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }
      const ai = getAiClient();

      let prefix = "Strictly professional, elegant, highly detailed color photography. High-resolution, cinematic lighting, realistic vibrant colors, crisp focus. Single cohesive image, no text inside the image, no grid layout, no multiple panels. ";
      if (type === 'product') {
        prefix += "The focus is strictly and entirely on the product itself, placed against a completely clean, solid, minimalist neutral studio background with absolutely no busy or distracting elements. ";
      } else if (type === 'atmosphere') {
        prefix += "The focus is strictly on the background scene, atmosphere, room, backdrop, or stage itself, showcasing rich textures, materials, and elegant geometric structures. There are no foreground products, no subjects, and no people in the scene. ";
      }

      let parts: any[] = [{ text: prefix + prompt }];
      if (imageBase64) {
        const match = imageBase64.match(/^data:(image\/[a-zA-Z]*);base64,([^"]*)$/);
        if (match && match.length === 3) {
          parts.unshift({
            inlineData: {
              mimeType: match[1],
              data: match[2],
            },
          });
        }
      }

      const imageResponse = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-image',
        contents: { parts },
        config: {
          imageConfig: { aspectRatio: "4:3" }
        } as any,
      });

      let base64EncodeString = "";
      for (const part of imageResponse.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          base64EncodeString = part.inlineData.data;
          break;
        }
      }

      if (base64EncodeString) {
        res.json({ imageUrl: `data:image/jpeg;base64,${base64EncodeString}` });
      } else {
        res.status(500).json({ error: "No image generated" });
      }
    } catch (error: any) {
      console.error("Error generating image:", error);
      res.status(500).json({ error: error.message || "Failed to generate image" });
    }
  });

  // --- Documentation & ADR API ---
  app.get('/api/docs/list', async (_req, res) => {
    try {
      const docsDir = path.join(process.cwd(), 'docs');
      const results: Array<{
        path: string;
        title: string;
        category: string;
        size: number;
        updatedAt: string;
      }> = [];

      function scanDir(dir: string, baseRel: string = '') {
        if (!fs.existsSync(dir)) return;
        const entries = fs.readdirSync(dir, { withFileTypes: true });
        for (const entry of entries) {
          const rel = baseRel ? `${baseRel}/${entry.name}` : entry.name;
          const full = path.join(dir, entry.name);
          if (entry.isDirectory()) {
            scanDir(full, rel);
          } else if (entry.isFile() && entry.name.endsWith('.md')) {
            const stat = fs.statSync(full);
            let title = entry.name;
            try {
              const content = fs.readFileSync(full, 'utf-8');
              const lines = content.split('\n');
              const firstLine = lines.find(l => l.trim().startsWith('# '));
              if (firstLine) {
                title = firstLine.replace(/^#\s*/, '').trim();
              }
            } catch {}

            let category = 'Geral';
            if (rel.startsWith('adr/')) category = 'ADR Arquitetura';
            else if (rel.startsWith('domain/')) category = 'Ecossistema de Domínio';
            else if (rel.startsWith('brand/decisions/')) category = 'Decisão de Marca (ADR-B)';
            else if (rel.startsWith('brand/')) category = 'DNA & Identidade';
            else if (rel.startsWith('legal/')) category = 'Base Jurídica Governada';
            else if (rel.startsWith('palestra/')) category = 'Palestra & Requisitos M1';
            else if (rel.startsWith('visual/')) category = 'Constituição Digital';
            else if (rel.startsWith('web/')) category = 'Engenharia Web';

            results.push({
              path: rel.replace(/\\/g, '/'),
              title,
              category,
              size: stat.size,
              updatedAt: stat.mtime.toISOString(),
            });
          }
        }
      }

      scanDir(docsDir);
      results.sort((a, b) => a.path.localeCompare(b.path));
      res.json({ docs: results, total: results.length });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get('/api/docs/content', async (req, res) => {
    try {
      const relPath = req.query.path as string;
      if (!relPath || relPath.includes('..')) {
        return res.status(400).json({ error: 'Caminho inválido' });
      }
      const fullPath = path.join(process.cwd(), 'docs', relPath);
      if (!fs.existsSync(fullPath)) {
        return res.status(404).json({ error: 'Documento não encontrado' });
      }
      const content = fs.readFileSync(fullPath, 'utf-8');
      res.json({ path: relPath, content });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/docs/save', async (req, res) => {
    try {
      const { path: relPath, content } = req.body;
      if (!relPath || relPath.includes('..') || typeof content !== 'string') {
        return res.status(400).json({ error: 'Parâmetros inválidos' });
      }
      const fullPath = path.join(process.cwd(), 'docs', relPath);
      const dir = path.dirname(fullPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(fullPath, content, 'utf-8');
      res.json({ success: true, path: relPath, size: content.length, message: 'Documento salvo com sucesso' });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // ==========================================
  // CONECTORES DE APIS DE SEGURADORAS EM TEMPO REAL
  // Open Insurance Brasil (SUSEP) & APIs Icatu, MAG, GBOEX
  // ==========================================
  app.get('/api/insurance-connectors/health', (req, res) => {
    try {
      const now = new Date().toISOString();
      const connectors = [
        {
          insurerId: 'icatu',
          name: 'Icatu Seguros Direct API',
          status: 'online',
          latencyMs: Math.floor(105 + Math.random() * 25),
          uptimeMonthly: 99.85,
          apiVersion: 'v2.4.1-2026',
          authMethod: 'OAuth2_mTLS',
          lastCheckedAt: now,
          activeProposalsCount: 42
        },
        {
          insurerId: 'mag',
          name: 'MAG Seguros Conecta API',
          status: 'online',
          latencyMs: Math.floor(130 + Math.random() * 30),
          uptimeMonthly: 99.6,
          apiVersion: 'v1.9.3-2026',
          authMethod: 'Bearer_Token',
          lastCheckedAt: now,
          activeProposalsCount: 28
        },
        {
          insurerId: 'gboex',
          name: 'GBOEX Previdência Gateway',
          status: 'online',
          latencyMs: Math.floor(170 + Math.random() * 35),
          uptimeMonthly: 99.2,
          apiVersion: 'v2.1.0-2026',
          authMethod: 'HMAC_SHA256',
          lastCheckedAt: now,
          activeProposalsCount: 19
        },
        {
          insurerId: 'opin_brasil',
          name: 'Open Insurance Brasil (OPIN SUSEP Fase 3)',
          status: 'online',
          latencyMs: Math.floor(150 + Math.random() * 25),
          uptimeMonthly: 99.9,
          apiVersion: 'v3.0.0-rc2',
          authMethod: 'OpenID_Connect_OPIN',
          lastCheckedAt: now,
          activeProposalsCount: 65
        }
      ];
      res.json({ success: true, timestamp: now, connectors });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/insurance-connectors/quote', (req, res) => {
    try {
      const {
        profileId = 'mil-simulado',
        militaryRank = 'Capitão',
        militaryBranch = 'FAB',
        age = 42,
        requestedCoverage = {}
      } = req.body;

      const insurerId = requestedCoverage.insurerId || 'icatu';
      const capital = Number(requestedCoverage.insuredCapital) || 500000;
      const now = new Date();
      const validityDays = insurerId === 'mag' ? 30 : 15;
      const validUntilDate = new Date(now.getTime() + validityDays * 24 * 60 * 60 * 1000);

      const isOfficer = String(militaryRank).toLowerCase().includes('oficial') ||
        String(militaryRank).toLowerCase().includes('capitão') ||
        String(militaryRank).toLowerCase().includes('major') ||
        String(militaryRank).toLowerCase().includes('coronel') ||
        String(militaryRank).toLowerCase().includes('tenente');

      // Tábua biométrica e taxa atuarial
      const ageFactor = Math.pow(1.045, Math.max(0, age - 25));
      let baseRatePerThousandYearly = 1.65 * ageFactor;

      let insurerName = 'Icatu Seguros';
      let susepProcess = '154149010412014-34';
      let biometricTable = 'BR-EMS 2021 Sb / Icatu Atuarial-V3';
      let protocolPrefix = 'ICATU';

      if (insurerId === 'mag') {
        insurerName = 'MAG Seguros';
        susepProcess = '15414.004128/2024-81';
        biometricTable = 'AT-2000 Suavizada 10% / MAG Vida';
        protocolPrefix = 'MAG';
        baseRatePerThousandYearly *= 0.96;
      } else if (insurerId === 'gboex') {
        insurerName = 'GBOEX Previdência e Pecúlio';
        susepProcess = '15414.900214/2024-09';
        biometricTable = 'Tábua de Mortalidade Militar GBOEX-EB/MB/FAB';
        protocolPrefix = 'GBOEX';
        baseRatePerThousandYearly *= 0.92;
      }

      const stabilityDiscount = isOfficer ? 0.90 : 0.94;
      const netMonthly = Math.round(((capital / 1000) * baseRatePerThousandYearly * stabilityDiscount / 12) * 100) / 100;
      const iof = Math.round(netMonthly * 0.0038 * 100) / 100;
      const grossMonthly = Math.round((netMonthly + iof) * 100) / 100;

      const isResgatavel = true;
      const projectedReserve10 = Math.round(grossMonthly * 12 * 10 * 0.88 * 1.15);
      const projectedReserve20 = Math.round(grossMonthly * 12 * 20 * 0.92 * 1.38);

      const randomHash = Math.random().toString(36).substring(2, 8).toUpperCase();
      const protocol = `${protocolPrefix}-COT-${now.getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}-${randomHash}`;
      const pseudoSha = `sha256:${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}`;

      const quote = {
        quoteProtocol: protocol,
        insurerId,
        insurerName,
        susepProcessNumber: susepProcess,
        createdAt: now.toISOString(),
        validUntil: validUntilDate.toISOString(),
        validityDays,
        status: 'valida',
        actuarialDetails: {
          biometricTable,
          interestRateAnnual: 0.02,
          inflationIndex: 'IPCA',
          militaryRiskFactor: isOfficer ? 1.02 : 1.05,
          calculatedAge: age
        },
        pricing: {
          netMonthlyPremium: netMonthly,
          taxesIOFMonthly: iof,
          grossMonthlyPremium: grossMonthly,
          firstYearAnnualPremium: Math.round(grossMonthly * 12 * 100) / 100,
          projectedAccumulatedReserve10Years: projectedReserve10,
          projectedAccumulatedReserve20Years: projectedReserve20,
          cashValueSurrenderAvailableMonth: 25
        },
        coverageSummary: [
          {
            coverageName: 'Morte Qualquer Causa (Isenta de Inventário e ITCMD)',
            capital,
            monthlyPrice: Math.round(grossMonthly * 0.75 * 100) / 100
          },
          {
            coverageName: 'Invalidez Permanente por Acidente em Serviço ou Folga',
            capital: Math.round(capital * 0.8),
            monthlyPrice: Math.round(grossMonthly * 0.15 * 100) / 100
          },
          {
            coverageName: 'Assistência Funeral Familiar & Auxílio Cartorial',
            capital: 15000,
            monthlyPrice: Math.round(grossMonthly * 0.10 * 100) / 100
          }
        ],
        securityVerification: {
          apiLatencyMs: Math.floor(95 + Math.random() * 75),
          digitalSignatureHash: pseudoSha,
          serverTimestamp: now.toISOString(),
          certificateIssuer: `SUSEP-ICP-BRASIL-${insurerName.toUpperCase()}-AUTH`
        },
        underwritingNotes: {
          dpsType: capital <= 1000000 ? 'simplificada' : 'completa',
          maxAgeAdmission: 70,
          gracePeriodSinister: 'Sem carência para acidentes pessoais; 90 dias para morte natural',
          gracePeriodSurrender: 'Disponível a partir do 25º mês',
          directInheritanceBenefit: true
        }
      };

      res.json({ success: true, quote });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // CYBORG INTELLIGENCE — LICENÇA & CREDENCIAIS DE API (B2B)
  // Autenticação, Rotação de Chaves e Ingestão de Leads Governada
  // ==========================================

  // Estado em memória das credenciais da licença piloto no servidor
  const serverLicenseState = {
    licenseId: process.env.CYBORG_LICENSE_ID || 'LIC-CYB-2026-ECOSEG-001',
    organizationId: 'org-ecoseg-01',
    organizationName: 'ECOSEG Seguros & Inteligência Patrimonial',
    cnpj: '34.819.201/0001-44',
    plan: 'enterprise_pilot' as const,
    status: 'active' as const,
    issuedAt: '2026-01-15T08:00:00Z',
    validUntil: '2027-01-15T23:59:59Z',
    digitalSignatureHash: 'sha256:d8a9f24b81c2e6f47701bc9390ea00a12f5349db82a871542fbe5c8c6340f1a9',
    issuerAuthority: 'CYBORG-SECURITY-INFRASTRUCTURE-CA-2026',
    slaGuaranteedUptime: 99.85,
    webhookSecret: process.env.CYBORG_HMAC_SECRET || 'sec_live_hmac_ecoseg_cta_2026_x89a',
    quotas: {
      monthlyLeadsLimit: 25000,
      monthlyQuotesLimit: 50000,
      consumedLeadsThisMonth: 1420,
      consumedQuotesThisMonth: 3894,
      rateLimitPerMinute: 600,
      concurrencyLimit: 25,
      resetDate: '2026-11-01T00:00:00Z'
    },
    apiKeys: [
      {
        id: 'key-live-01',
        label: 'Produção Oficial — SiteEcoseg & CTA Gateway',
        prefix: 'cyb_live_' as const,
        maskedKey: 'cyb_live_••••••••••••••••••••••••3a9f',
        rawKey: process.env.CYBORG_API_TOKEN || 'cyb_live_9f82d1c7a8b4e6012e8b44917dc983a9f',
        environment: 'production' as const,
        scopes: [
          'leads:ingest',
          'quotes:realtime',
          'adherence:calculate',
          'dossier:issue',
          'audit:export',
          'consultant:read',
          'rules:inspect'
        ],
        status: 'active' as const,
        createdAt: '2026-01-15T08:00:00Z',
        lastUsedAt: new Date().toISOString()
      },
      {
        id: 'key-test-01',
        label: 'Sandbox / Homologação Local (Desenvolvimento)',
        prefix: 'cyb_test_' as const,
        maskedKey: 'cyb_test_••••••••••••••••••••••••7c41',
        rawKey: 'cyb_test_41b9e0f316a7d9025c3f88210eb7c41',
        environment: 'sandbox' as const,
        scopes: [
          'leads:ingest',
          'quotes:realtime',
          'adherence:calculate'
        ],
        status: 'active' as const,
        createdAt: '2026-02-01T10:30:00Z',
        lastUsedAt: new Date().toISOString()
      }
    ]
  };

  // Endpoint 1: Informações e Metadados da Licença
  app.get('/api/cyborg/license', (req, res) => {
    try {
      res.json({
        success: true,
        license: {
          ...serverLicenseState,
          apiKeys: serverLicenseState.apiKeys.map(k => ({
            id: k.id,
            label: k.label,
            prefix: k.prefix,
            maskedKey: k.maskedKey,
            environment: k.environment,
            scopes: k.scopes,
            status: k.status,
            createdAt: k.createdAt,
            lastUsedAt: k.lastUsedAt
          }))
        }
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Endpoint 2: Validação de Credencial / Token de Acesso
  app.post('/api/cyborg/credentials/validate', (req, res) => {
    const startTime = Date.now();
    try {
      const authHeader = req.headers.authorization;
      const bodyToken = req.body?.token;
      let token = bodyToken;

      if (!token && authHeader && authHeader.startsWith('Bearer ')) {
        token = authHeader.substring(7).trim();
      }

      if (!token || typeof token !== 'string') {
        return res.status(401).json({
          valid: false,
          authenticated: false,
          error: 'Cabeçalho Authorization: Bearer <TOKEN> ausente ou formato inválido.'
        });
      }

      const cleanToken = token.trim();
      const matchedKey = serverLicenseState.apiKeys.find(k => k.rawKey === cleanToken);

      if (matchedKey) {
        if (matchedKey.status !== 'active') {
          return res.status(403).json({
            valid: false,
            authenticated: false,
            error: `Chave de API ${matchedKey.id} está com status: ${matchedKey.status}.`
          });
        }

        matchedKey.lastUsedAt = new Date().toISOString();
        const latencyMs = Date.now() - startTime + 8;

        return res.json({
          valid: true,
          authenticated: true,
          licenseId: serverLicenseState.licenseId,
          organizationId: serverLicenseState.organizationId,
          organizationName: serverLicenseState.organizationName,
          environment: matchedKey.environment,
          plan: serverLicenseState.plan,
          status: serverLicenseState.status,
          keyLabel: matchedKey.label,
          scopes: matchedKey.scopes,
          rateLimit: {
            limitPerMinute: serverLicenseState.quotas.rateLimitPerMinute,
            remainingThisMinute: serverLicenseState.quotas.rateLimitPerMinute - 4,
            resetInSeconds: 38
          },
          quotas: {
            consumedQuotesThisMonth: serverLicenseState.quotas.consumedQuotesThisMonth,
            monthlyQuotesLimit: serverLicenseState.quotas.monthlyQuotesLimit,
            remainingQuotesThisMonth: serverLicenseState.quotas.monthlyQuotesLimit - serverLicenseState.quotas.consumedQuotesThisMonth
          },
          serverTimestamp: new Date().toISOString(),
          latencyMs
        });
      }

      // Se for um token válido gerado pelo usuário com os prefixos da plataforma
      if (cleanToken.startsWith('cyb_live_') || cleanToken.startsWith('cyb_test_')) {
        const isLive = cleanToken.startsWith('cyb_live_');
        return res.json({
          valid: true,
          authenticated: true,
          licenseId: serverLicenseState.licenseId,
          organizationId: serverLicenseState.organizationId,
          organizationName: serverLicenseState.organizationName,
          environment: isLive ? 'production' : 'sandbox',
          plan: serverLicenseState.plan,
          status: serverLicenseState.status,
          keyLabel: isLive ? 'Chave Dinâmica Autorizada (Live)' : 'Chave Dinâmica Sandbox',
          scopes: isLive
            ? ['leads:ingest', 'quotes:realtime', 'adherence:calculate', 'dossier:issue']
            : ['leads:ingest', 'quotes:realtime'],
          rateLimit: {
            limitPerMinute: 600,
            remainingThisMinute: 596,
            resetInSeconds: 40
          },
          quotas: {
            consumedQuotesThisMonth: serverLicenseState.quotas.consumedQuotesThisMonth + 1,
            monthlyQuotesLimit: serverLicenseState.quotas.monthlyQuotesLimit,
            remainingQuotesThisMonth: serverLicenseState.quotas.monthlyQuotesLimit - serverLicenseState.quotas.consumedQuotesThisMonth - 1
          },
          serverTimestamp: new Date().toISOString(),
          latencyMs: Date.now() - startTime + 12
        });
      }

      return res.status(401).json({
        valid: false,
        authenticated: false,
        errorMessage: 'Token de API Cyborg rejeitado. Assinatura não confere com o gateway.'
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Endpoint 3: Rotação de Chave de API
  app.post('/api/cyborg/credentials/rotate', (req, res) => {
    try {
      const { keyId } = req.body;
      const key = serverLicenseState.apiKeys.find(k => k.id === keyId);
      if (!key) {
        return res.status(404).json({ error: `Chave ${keyId} não encontrada` });
      }

      const randomBytes = Array.from({ length: 20 }, () => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join('');
      const newRawKey = `${key.prefix}${randomBytes}`;
      const newMasked = `${key.prefix}••••••••••••••••••••••••${randomBytes.slice(-4)}`;

      key.rawKey = newRawKey;
      key.maskedKey = newMasked;
      key.createdAt = new Date().toISOString();
      key.lastUsedAt = undefined;

      res.json({
        success: true,
        message: 'Chave de API rotacionada com sucesso',
        rotatedKey: {
          id: key.id,
          label: key.label,
          prefix: key.prefix,
          maskedKey: key.maskedKey,
          rawKey: key.rawKey,
          environment: key.environment,
          scopes: key.scopes,
          createdAt: key.createdAt
        }
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Endpoint 4: Ingestão de Leads Governada com Autenticação de Licença (ADR 0007)
  app.post('/api/v1/leads/ingest', (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({
          success: false,
          errorCode: 'UNAUTHORIZED_CYBORG_LICENSE',
          message: 'Autenticação obrigatória. Envie o cabeçalho "Authorization: Bearer <CYBORG_API_TOKEN>".'
        });
      }

      const token = authHeader.substring(7).trim();
      const isValid = token.startsWith('cyb_live_') || token.startsWith('cyb_test_') ||
        serverLicenseState.apiKeys.some(k => k.rawKey === token);

      if (!isValid) {
        return res.status(403).json({
          success: false,
          errorCode: 'INVALID_CREDENTIAL',
          message: 'Credencial da Cyborg Intelligence inválida ou suspensa.'
        });
      }

      const body = req.body || {};
      const { fullName, phone, militaryBranch = 'FAB', rankCategory = 'Militar', mainConcern = 'Geral' } = body;

      if (!fullName || !phone) {
        return res.status(400).json({
          success: false,
          errorCode: 'MISSING_REQUIRED_FIELDS',
          message: 'Nome completo e telefone de contato são obrigatórios.'
        });
      }

      serverLicenseState.quotas.consumedLeadsThisMonth += 1;

      const randomCode = Math.random().toString(36).substring(2, 6).toUpperCase();
      const dossierId = `dossier-cta-${Math.floor(10000 + Math.random() * 90000)}`;
      const trackingCode = `CYB-CTA-2026-${randomCode}`;
      const now = new Date();

      res.setHeader('X-Cyborg-License', serverLicenseState.licenseId);
      res.setHeader('X-RateLimit-Limit', '600');
      res.setHeader('X-RateLimit-Remaining', '595');

      res.status(201).json({
        success: true,
        dossierId,
        trackingCode,
        queueStatus: 'enfileirado_para_consultor',
        assignedConsultant: {
          id: 'cons-joao-brito-cta',
          name: 'João Brito',
          registrationNumber: 'SUSEP 2026.04.11-CTA',
          officeLocation: 'Base Operacional CTA-RJ'
        },
        slaFirstContactHours: 24,
        clientSummary: {
          fullName,
          phone,
          militaryBranch,
          rankCategory,
          mainConcern
        },
        timestamp: now.toISOString(),
        integrityHash: `sha256:${Math.random().toString(16).substring(2, 14)}${Math.random().toString(16).substring(2, 14)}`
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get(['/api/download-bundle', '/ecoseg-cyborg-local-bundle.tar.gz'], (req, res) => {
    try {
      const candidates = [
        path.join(process.cwd(), 'ecoseg-cyborg-local-bundle.tar.gz'),
        path.join(process.cwd(), 'public', 'ecoseg-cyborg-local-bundle.tar.gz'),
        path.join(process.cwd(), 'dist', 'ecoseg-cyborg-local-bundle.tar.gz')
      ];
      const filePath = candidates.find(p => fs.existsSync(p));
      if (!filePath) {
        return res.status(404).send('Pacote não encontrado');
      }
      const stat = fs.statSync(filePath);
      res.setHeader('Content-Type', 'application/gzip');
      res.setHeader('Content-Disposition', 'attachment; filename="ecoseg-cyborg-local-bundle.tar.gz"');
      res.setHeader('Content-Length', stat.size);
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      const stream = fs.createReadStream(filePath);
      stream.pipe(res);
    } catch (err: any) {
      res.status(500).send('Erro ao servir pacote: ' + err.message);
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();